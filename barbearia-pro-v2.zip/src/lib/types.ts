// Tipos TypeScript para o Sistema de Gestão de Barbearia Pro

// ==================== ENTIDADES PRINCIPAIS ====================

export interface Barbeiro {
  id: string;
  nome: string;
  telefone?: string;
  email?: string;
  foto?: string;
  ativo: boolean;
  comissao: number; // Percentual de comissão (0-100)
  dataCadastro: string;
}

export interface Servico {
  id: string;
  nome: string;
  preco: number;
  duracao?: number; // Em minutos
  descricao?: string;
  categoria?: string;
  ativo: boolean;
}

export type FormaPagamento = 'dinheiro' | 'cartao' | 'pix' | 'voucher';

export interface Venda {
  id: string;
  barbeiroId: string;
  barbeiroNome: string;
  clienteId?: string;
  clienteNome?: string;
  servicoId: string;
  servicoNome: string;
  preco: number;
  formaPagamento: FormaPagamento;
  data: string;
  hora: string;
  comissao?: number; // Valor da comissão calculada
  observacao?: string;
}

// ==================== CLIENTES ====================

export interface Cliente {
  id: string;
  nome: string;
  telefone: string;
  email?: string;
  dataNascimento?: string;
  observacoes?: string;
  dataCadastro: string;
  totalVisitas: number;
  totalGasto: number;
  ultimoVisita?: string;
}

// ==================== AGENDAMENTOS ====================

export type StatusAgendamento = 'pendente' | 'confirmado' | 'concluido' | 'cancelado' | 'nao_compareceu';

export interface Agendamento {
  id: string;
  clienteId: string;
  clienteNome: string;
  clienteTelefone: string;
  barbeiroId: string;
  barbeiroNome: string;
  servicoId: string;
  servicoNome: string;
  data: string; // YYYY-MM-DD
  hora: string; // HH:MM
  duracao: number; // Em minutos
  preco: number;
  status: StatusAgendamento;
  observacao?: string;
  dataCriacao: string;
}

// ==================== DESPESAS ====================

export type CategoriaDespesa = 
  | 'aluguel' 
  | 'agua' 
  | 'luz' 
  | 'internet' 
  | 'produtos' 
  | 'equipamentos' 
  | 'salario' 
  | 'comissao' 
  | 'marketing' 
  | 'manutencao' 
  | 'outros';

export interface Despesa {
  id: string;
  descricao: string;
  valor: number;
  categoria: CategoriaDespesa;
  data: string;
  dataVencimento?: string;
  paga: boolean;
  dataPagamento?: string;
  observacao?: string;
  recorrente: boolean;
  frequencia?: 'diaria' | 'semanal' | 'mensal' | 'anual';
}

// ==================== PRODUTOS ====================

export interface Produto {
  id: string;
  nome: string;
  descricao?: string;
  precoCompra: number;
  precoVenda: number;
  quantidadeEstoque: number;
  estoqueMinimo: number;
  codigo?: string;
  fornecedor?: string;
  dataCadastro: string;
  ativo: boolean;
}

export interface VendaProduto {
  id: string;
  produtoId: string;
  produtoNome: string;
  quantidade: number;
  precoUnitario: number;
  total: number;
  barbeiroId?: string;
  barbeiroNome?: string;
  formaPagamento: FormaPagamento;
  data: string;
  hora: string;
}

// ==================== ESTADO DA APLICAÇÃO ====================

export interface AppState {
  barbeiros: Barbeiro[];
  servicos: Servico[];
  vendas: Venda[];
  clientes: Cliente[];
  agendamentos: Agendamento[];
  despesas: Despesa[];
  produtos: Produto[];
  vendasProdutos: VendaProduto[];
  barbeiroAtivoId: string | null;
}

// ==================== RELATÓRIOS ====================

export interface RelatorioBarbeiro {
  barbeiroId: string;
  barbeiroNome: string;
  totalVendas: number;
  quantidadeVendas: number;
  comissaoTotal: number;
  servicos: { nome: string; quantidade: number; total: number }[];
}

export interface RelatorioServico {
  servicoId: string;
  servicoNome: string;
  quantidade: number;
  total: number;
}

export interface RelatorioDiario {
  data: string;
  totalGeral: number;
  totalVendas: number;
  totalDespesas: number;
  lucroLiquido: number;
  porBarbeiro: RelatorioBarbeiro[];
  porServico: RelatorioServico[];
  porFormaPagamento: {
    dinheiro: number;
    cartao: number;
    pix: number;
    voucher: number;
  };
}

export interface RelatorioMensal {
  mes: string;
  ano: number;
  totalGeral: number;
  totalVendas: number;
  totalDespesas: number;
  lucroLiquido: number;
  ticketMedio: number;
  crescimentoPercentual: number;
  diasUteis: number;
  mediaDiaria: number;
}

// ==================== DASHBOARD ====================

export interface DashboardStats {
  totalHoje: number;
  vendasHoje: number;
  agendamentosHoje: number;
  clientesAtivos: number;
  ticketMedio: number;
  crescimentoSemanal: number;
  despesasMes: number;
  lucroEstimado: number;
}

// ==================== BACKUP ====================

export interface BackupData {
  versao: string;
  dataExportacao: string;
  barbeiros: Barbeiro[];
  servicos: Servico[];
  vendas: Venda[];
  clientes: Cliente[];
  agendamentos: Agendamento[];
  despesas: Despesa[];
  produtos: Produto[];
  vendasProdutos: VendaProduto[];
}

// ==================== NAVIGAÇÃO ====================

export type TabId = 'dashboard' | 'vendas' | 'clientes' | 'agendamentos' | 'despesas' | 'relatorios' | 'configuracoes';

export interface TabItem {
  id: TabId;
  label: string;
  icon: string;
}
