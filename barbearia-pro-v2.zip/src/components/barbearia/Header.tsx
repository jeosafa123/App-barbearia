'use client';

import { Scissors, BarChart3, UserPlus, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { useState } from 'react';

interface HeaderProps {
  onAddBarbeiro: (nome: string) => void;
  onOpenRelatorio: () => void;
}

export default function Header({ onAddBarbeiro, onOpenRelatorio }: HeaderProps) {
  const [novoBarbeiroNome, setNovoBarbeiroNome] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);

  const handleAddBarbeiro = () => {
    if (novoBarbeiroNome.trim()) {
      onAddBarbeiro(novoBarbeiroNome.trim());
      setNovoBarbeiroNome('');
      setDialogOpen(false);
    }
  };

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-card/80 backdrop-blur-sm">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
            <Scissors className="h-5 w-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-primary">Barbearia Pro</h1>
            <p className="text-xs text-muted-foreground">Sistema de Gestão</p>
          </div>
        </div>

        {/* Ações */}
        <div className="flex items-center gap-2">
          {/* Botão de Relatório */}
          <Button
            variant="outline"
            size="sm"
            onClick={onOpenRelatorio}
            className="border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground"
          >
            <BarChart3 className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Relatório</span>
          </Button>

          {/* Dialog para adicionar barbeiro */}
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button
                size="sm"
                className="bg-primary text-primary-foreground hover:bg-primary/90"
              >
                <UserPlus className="mr-2 h-4 w-4" />
                <span className="hidden sm:inline">Novo Barbeiro</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-border">
              <DialogHeader>
                <DialogTitle className="text-primary">Adicionar Barbeiro</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <Input
                  placeholder="Nome do barbeiro"
                  value={novoBarbeiroNome}
                  onChange={(e) => setNovoBarbeiroNome(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddBarbeiro()}
                  className="border-border bg-secondary focus:border-primary"
                />
                <div className="flex justify-end gap-2">
                  <Button
                    variant="outline"
                    onClick={() => setDialogOpen(false)}
                    className="border-border"
                  >
                    Cancelar
                  </Button>
                  <Button
                    onClick={handleAddBarbeiro}
                    className="bg-primary text-primary-foreground hover:bg-primary/90"
                  >
                    Adicionar
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </header>
  );
}
