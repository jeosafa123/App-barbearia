'use client';

import { useState, useMemo } from 'react';
import { 
  Calendar, Plus, Clock, User, Scissors, Check, X,
  ChevronLeft, ChevronRight, Phone, Edit2, Trash2,
  AlertCircle, CheckCircle2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { Agendamento, StatusAgendamento, Barbeiro, Servico, Cliente } from '@/lib/types';

interface AgendamentosSectionProps {
  agendamentos: Agendamento[];
  barbeiros: Barbeiro[];
  servicos: Servico[];
  clientes: Cliente[];
  onAddAgendamento: (agendamento: Omit<Agendamento, 'id' | 'dataCriacao'>) => void;
  onUpdateStatus: (id: string, status: StatusAgendamento) => void;
  onDeleteAgendamento: (id: string) => void;
}

const STATUS_CONFIG: Record<StatusAgendamento, { label: string; color: string; bgColor: string }> = {
  pendente: { label: 'Pendente', color: 'text-yellow-400', bgColor: 'bg-yellow-400/20 border-yellow-400/30' },
  confirmado: { label: 'Confirmado', color: 'text-blue-400', bgColor: 'bg-blue-400/20 border-blue-400/30' },
  concluido: { label: 'Concluído', color: 'text-green-400', bgColor: 'bg-green-400/20 border-green-400/30' },
  cancelado: { label: 'Cancelado', color: 'text-red-400', bgColor: 'bg-red-400/20 border-red-400/30' },
  nao_compareceu: { label: 'Não compareceu', color: 'text-gray-400', bgColor: 'bg-gray-400/20 border-gray-400/30' },
};

const HORARIOS = [
  '08:00', '08:30', '09:00', '09:30', '10:00', '10:30',
  '11:00', '11:30', '12:00', '12:30', '13:00', '13:30',
  '14:00', '14:30', '15:00', '15:30', '16:00', '16:30',
  '17:00', '17:30', '18:00', '18:30', '19:00', '19:30',
  '20:00', '20:30', '21:00',
];

export default function AgendamentosSection({
  agendamentos,
  barbeiros,
  servicos,
  clientes,
  onAddAgendamento,
  onUpdateStatus,
  onDeleteAgendamento,
}: AgendamentosSectionProps) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [viewMode, setViewMode] = useState<'day' | 'week'>('day');
  
  // Form state
  const [formData, setFormData] = useState({
    clienteId: '',
    clienteNome: '',
    clienteTelefone: '',
    barbeiroId: '',
    servicoId: '',
    data: selectedDate,
    hora: '',
    observacao: '',
  });

  const resetForm = () => {
    setFormData({
      clienteId: '',
      clienteNome: '',
      clienteTelefone: '',
      barbeiroId: '',
      servicoId: '',
      data: selectedDate,
      hora: '',
      observacao: '',
    });
  };

  // Navegar datas
  const navigateDate = (direction: 'prev' | 'next') => {
    const current = new Date(selectedDate);
    if (viewMode === 'day') {
      current.setDate(current.getDate() + (direction === 'next' ? 1 : -1));
    } else {
      current.setDate(current.getDate() + (direction === 'next' ? 7 : -7));
    }
    setSelectedDate(current.toISOString().split('T')[0]);
  };

  // Agendamentos do dia selecionado
  const agendamentosDoDia = useMemo(() => {
    return agendamentos
      .filter((a) => a.data === selectedDate)
      .sort((a, b) => a.hora.localeCompare(b.hora));
  }, [agendamentos, selectedDate]);

  // Agrupar por horário
  const agendamentosPorHorario = useMemo(() => {
    const map = new Map<string, Agendamento[]>();
    HORARIOS.forEach((h) => map.set(h, []));
    agendamentosDoDia.forEach((a) => {
      const agendamentosNoHorario = map.get(a.hora) || [];
      agendamentosNoHorario.push(a);
      map.set(a.hora, agendamentosNoHorario);
    });
    return map;
  }, [agendamentosDoDia]);

  // Estatísticas do dia
  const statsDoDia = useMemo(() => {
    const total = agendamentosDoDia.length;
    const pendentes = agendamentosDoDia.filter((a) => a.status === 'pendente').length;
    const confirmados = agendamentosDoDia.filter((a) => a.status === 'confirmado').length;
    const concluidos = agendamentosDoDia.filter((a) => a.status === 'concluido').length;
    return { total, pendentes, confirmados, concluidos };
  }, [agendamentosDoDia]);

  const handleClienteSelect = (clienteId: string) => {
    const cliente = clientes.find((c) => c.id === clienteId);
    if (cliente) {
      setFormData({
        ...formData,
        clienteId: cliente.id,
        clienteNome: cliente.nome,
        clienteTelefone: cliente.telefone,
      });
    }
  };

  const handleServicoSelect = (servicoId: string) => {
    const servico = servicos.find((s) => s.id === servicoId);
    if (servico) {
      setFormData({
        ...formData,
        servicoId: servico.id,
      });
    }
  };

  const handleAddAgendamento = () => {
    const barbeiro = barbeiros.find((b) => b.id === formData.barbeiroId);
    const servico = servicos.find((s) => s.id === formData.servicoId);
    
    if (
      formData.clienteNome.trim() &&
      formData.clienteTelefone.trim() &&
      barbeiro &&
      servico &&
      formData.hora
    ) {
      onAddAgendamento({
        clienteId: formData.clienteId || 'walk-in',
        clienteNome: formData.clienteNome,
        clienteTelefone: formData.clienteTelefone,
        barbeiroId: barbeiro.id,
        barbeiroNome: barbeiro.nome,
        servicoId: servico.id,
        servicoNome: servico.nome,
        data: formData.data,
        hora: formData.hora,
        duracao: servico.duracao || 30,
        preco: servico.preco,
        status: 'pendente',
        observacao: formData.observacao || undefined,
      });
      resetForm();
      setDialogOpen(false);
    }
  };

  // Formatar data para exibição
  const formatDataExibicao = (dataStr: string) => {
    const data = new Date(dataStr + 'T12:00:00');
    const diasSemana = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
    const diaSemana = diasSemana[data.getDay()];
    const dia = data.getDate();
    const mes = data.toLocaleDateString('pt-BR', { month: 'short' });
    return `${diaSemana}, ${dia} ${mes}`;
  };

  // Verificar se é hoje
  const isHoje = selectedDate === new Date().toISOString().split('T')[0];

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
        <div className="flex items-center gap-2">
          <Calendar className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold text-foreground">Agendamentos</h2>
        </div>
        
        <Button
          onClick={() => {
            resetForm();
            setFormData((prev) => ({ ...prev, data: selectedDate }));
            setDialogOpen(true);
          }}
          className="bg-primary text-primary-foreground hover:bg-primary/90"
        >
          <Plus className="h-4 w-4 mr-1" />
          Novo Agendamento
        </Button>
      </div>

      {/* Navegação de data */}
      <Card className="bg-card border-border">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigateDate('prev')}
              className="text-muted-foreground hover:text-foreground"
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>
            
            <div className="flex items-center gap-4">
              <div className="text-center">
                <p className={`text-lg font-semibold ${isHoje ? 'text-primary' : 'text-foreground'}`}>
                  {formatDataExibicao(selectedDate)}
                </p>
                {isHoje && (
                  <Badge variant="outline" className="border-primary text-primary">
                    Hoje
                  </Badge>
                )}
              </div>
              
              <Input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-auto bg-secondary border-border"
              />
            </div>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigateDate('next')}
              className="text-muted-foreground hover:text-foreground"
            >
              <ChevronRight className="h-5 w-5" />
            </Button>
          </div>

          {/* Stats do dia */}
          <div className="flex justify-center gap-6 mt-4">
            <div className="text-center">
              <p className="text-xl font-bold text-foreground">{statsDoDia.total}</p>
              <p className="text-xs text-muted-foreground">Total</p>
            </div>
            <div className="text-center">
              <p className="text-xl font-bold text-yellow-400">{statsDoDia.pendentes}</p>
              <p className="text-xs text-muted-foreground">Pendentes</p>
            </div>
            <div className="text-center">
              <p className="text-xl font-bold text-blue-400">{statsDoDia.confirmados}</p>
              <p className="text-xs text-muted-foreground">Confirmados</p>
            </div>
            <div className="text-center">
              <p className="text-xl font-bold text-green-400">{statsDoDia.concluidos}</p>
              <p className="text-xs text-muted-foreground">Concluídos</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Timeline de agendamentos */}
      {agendamentosDoDia.length === 0 ? (
        <Card className="border-dashed border-border bg-card/50">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Calendar className="mb-4 h-12 w-12 text-muted-foreground" />
            <p className="text-lg text-muted-foreground">
              Nenhum agendamento para este dia
            </p>
            <p className="text-sm text-muted-foreground/70 mt-1">
              Clique em "Novo Agendamento" para começar
            </p>
          </CardContent>
        </Card>
      ) : (
        <ScrollArea className="max-h-[400px]">
          <div className="space-y-2 pr-4">
            {Array.from(agendamentosPorHorario.entries())
              .filter(([, agendamentos]) => agendamentos.length > 0)
              .map(([hora, agendamentosHora]) => (
                <div key={hora} className="flex gap-3">
                  {/* Horário */}
                  <div className="w-16 py-2 text-right">
                    <span className="text-sm font-medium text-muted-foreground">
                      {hora}
                    </span>
                  </div>
                  
                  {/* Agendamentos */}
                  <div className="flex-1 space-y-2">
                    {agendamentosHora.map((agendamento) => (
                      <Card
                        key={agendamento.id}
                        className={`transition-all duration-200 border-border bg-card hover:border-primary/50`}
                      >
                        <CardContent className="p-3">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className={`flex h-10 w-10 items-center justify-center rounded-full ${
                                STATUS_CONFIG[agendamento.status].bgColor
                              }`}>
                                <User className={`h-5 w-5 ${STATUS_CONFIG[agendamento.status].color}`} />
                              </div>
                              <div>
                                <p className="font-medium text-foreground">
                                  {agendamento.clienteNome}
                                </p>
                                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                  <span className="flex items-center gap-1">
                                    <Scissors className="h-3 w-3" />
                                    {agendamento.servicoNome}
                                  </span>
                                  <span>•</span>
                                  <span>{agendamento.barbeiroNome}</span>
                                </div>
                              </div>
                            </div>
                            
                            <div className="flex items-center gap-2">
                              <Badge
                                variant="outline"
                                className={STATUS_CONFIG[agendamento.status].bgColor}
                              >
                                {STATUS_CONFIG[agendamento.status].label}
                              </Badge>
                              
                              {/* Ações rápidas */}
                              <div className="flex gap-1">
                                {agendamento.status === 'pendente' && (
                                  <>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-8 w-8 text-blue-400 hover:bg-blue-400/20"
                                      onClick={() => onUpdateStatus(agendamento.id, 'confirmado')}
                                      title="Confirmar"
                                    >
                                      <Check className="h-4 w-4" />
                                    </Button>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-8 w-8 text-red-400 hover:bg-red-400/20"
                                      onClick={() => onUpdateStatus(agendamento.id, 'cancelado')}
                                      title="Cancelar"
                                    >
                                      <X className="h-4 w-4" />
                                    </Button>
                                  </>
                                )}
                                {agendamento.status === 'confirmado' && (
                                  <>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-8 w-8 text-green-400 hover:bg-green-400/20"
                                      onClick={() => onUpdateStatus(agendamento.id, 'concluido')}
                                      title="Concluir"
                                    >
                                      <CheckCircle2 className="h-4 w-4" />
                                    </Button>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-8 w-8 text-gray-400 hover:bg-gray-400/20"
                                      onClick={() => onUpdateStatus(agendamento.id, 'nao_compareceu')}
                                      title="Não compareceu"
                                    >
                                      <AlertCircle className="h-4 w-4" />
                                    </Button>
                                  </>
                                )}
                                
                                <AlertDialog>
                                  <AlertDialogTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-8 w-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  </AlertDialogTrigger>
                                  <AlertDialogContent className="bg-card border-border">
                                    <AlertDialogHeader>
                                      <AlertDialogTitle className="text-foreground">
                                        Excluir Agendamento
                                      </AlertDialogTitle>
                                      <AlertDialogDescription className="text-muted-foreground">
                                        Tem certeza que deseja excluir o agendamento de{' '}
                                        <strong>{agendamento.clienteNome}</strong>?
                                      </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                      <AlertDialogCancel className="border-border">
                                        Cancelar
                                      </AlertDialogCancel>
                                      <AlertDialogAction
                                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                        onClick={() => onDeleteAgendamento(agendamento.id)}
                                      >
                                        Excluir
                                      </AlertDialogAction>
                                    </AlertDialogFooter>
                                  </AlertDialogContent>
                                </AlertDialog>
                              </div>
                            </div>
                          </div>
                          
                          {agendamento.observacao && (
                            <p className="mt-2 text-sm text-muted-foreground bg-secondary/50 p-2 rounded">
                              {agendamento.observacao}
                            </p>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              ))}
          </div>
        </ScrollArea>
      )}

      {/* Dialog Novo Agendamento */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-card border-border max-w-md">
          <DialogHeader>
            <DialogTitle className="text-primary">Novo Agendamento</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 pt-4">
            {/* Seleção de cliente */}
            <div className="space-y-2">
              <label className="text-sm text-muted-foreground">Cliente</label>
              <Select onValueChange={handleClienteSelect}>
                <SelectTrigger className="bg-secondary border-border">
                  <SelectValue placeholder="Selecione um cliente" />
                </SelectTrigger>
                <SelectContent className="bg-card border-border">
                  {clientes.map((cliente) => (
                    <SelectItem key={cliente.id} value={cliente.id}>
                      {cliente.nome} - {cliente.telefone}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              {/* Campos manuais se não selecionar cliente */}
              <Input
                placeholder="Nome do cliente *"
                value={formData.clienteNome}
                onChange={(e) => setFormData({ ...formData, clienteNome: e.target.value })}
                className="border-border bg-secondary focus:border-primary"
              />
              <Input
                placeholder="Telefone *"
                value={formData.clienteTelefone}
                onChange={(e) => setFormData({ ...formData, clienteTelefone: e.target.value })}
                className="border-border bg-secondary focus:border-primary"
              />
            </div>

            {/* Barbeiro */}
            <div className="space-y-2">
              <label className="text-sm text-muted-foreground">Barbeiro</label>
              <Select
                value={formData.barbeiroId}
                onValueChange={(value) => setFormData({ ...formData, barbeiroId: value })}
              >
                <SelectTrigger className="bg-secondary border-border">
                  <SelectValue placeholder="Selecione o barbeiro" />
                </SelectTrigger>
                <SelectContent className="bg-card border-border">
                  {barbeiros.map((barbeiro) => (
                    <SelectItem key={barbeiro.id} value={barbeiro.id}>
                      {barbeiro.nome}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Serviço */}
            <div className="space-y-2">
              <label className="text-sm text-muted-foreground">Serviço</label>
              <Select
                value={formData.servicoId}
                onValueChange={handleServicoSelect}
              >
                <SelectTrigger className="bg-secondary border-border">
                  <SelectValue placeholder="Selecione o serviço" />
                </SelectTrigger>
                <SelectContent className="bg-card border-border">
                  {servicos.map((servico) => (
                    <SelectItem key={servico.id} value={servico.id}>
                      {servico.nome} - R$ {servico.preco.toFixed(2)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Data e Hora */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <label className="text-sm text-muted-foreground">Data</label>
                <Input
                  type="date"
                  value={formData.data}
                  onChange={(e) => setFormData({ ...formData, data: e.target.value })}
                  className="border-border bg-secondary focus:border-primary"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm text-muted-foreground">Horário</label>
                <Select
                  value={formData.hora}
                  onValueChange={(value) => setFormData({ ...formData, hora: value })}
                >
                  <SelectTrigger className="bg-secondary border-border">
                    <SelectValue placeholder="Horário" />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    {HORARIOS.map((hora) => (
                      <SelectItem key={hora} value={hora}>
                        {hora}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Observação */}
            <Input
              placeholder="Observação (opcional)"
              value={formData.observacao}
              onChange={(e) => setFormData({ ...formData, observacao: e.target.value })}
              className="border-border bg-secondary focus:border-primary"
            />
          </div>

          <DialogFooter className="mt-4">
            <Button
              variant="outline"
              onClick={() => {
                resetForm();
                setDialogOpen(false);
              }}
              className="border-border"
            >
              Cancelar
            </Button>
            <Button
              onClick={handleAddAgendamento}
              disabled={
                !formData.clienteNome.trim() ||
                !formData.clienteTelefone.trim() ||
                !formData.barbeiroId ||
                !formData.servicoId ||
                !formData.hora
              }
              className="bg-primary text-primary-foreground hover:bg-primary/90"
            >
              Agendar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
