'use client';

import { DollarSign, TrendingUp, TrendingDown, Users, Scissors, 
  Calendar, CreditCard, Smartphone, Wallet,
  ArrowUpRight, ArrowDownRight, Activity
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
} from 'recharts';
import type { Venda, Barbeiro, Servico, Agendamento, Despesa, Cliente } from '@/lib/types';

interface DashboardSectionProps {
  vendas: Venda[];
  barbeiros: Barbeiro[];
  servicos: Servico[];
  agendamentos: Agendamento[];
  despesas: Despesa[];
  clientes: Cliente[];
}

export default function DashboardSection({
  vendas,
  barbeiros,
  servicos,
  agendamentos,
  despesas,
  clientes,
}: DashboardSectionProps) {
  // Cálculos
  const hoje = new Date().toISOString().split('T')[0];
  const mesAtual = new Date().toISOString().slice(0, 7);
  
  // Vendas de hoje
  const vendasHoje = vendas.filter((v) => v.data === hoje);
  const totalHoje = vendasHoje.reduce((acc, v) => acc + v.preco, 0);
  
  // Vendas do mês
  const vendasMes = vendas.filter((v) => v.data.startsWith(mesAtual));
  const totalMes = vendasMes.reduce((acc, v) => acc + v.preco, 0);
  
  // Despesas do mês
  const despesasMes = despesas.filter((d) => d.data.startsWith(mesAtual));
  const totalDespesasMes = despesasMes.reduce((acc, d) => acc + d.valor, 0);
  
  // Lucro estimado
  const lucroEstimado = totalMes - totalDespesasMes;
  
  // Agendamentos de hoje
  const agendamentosHoje = agendamentos.filter((a) => a.data === hoje);
  const agendamentosPendentes = agendamentosHoje.filter((a) => a.status === 'pendente' || a.status === 'confirmado');
  
  // Ticket médio
  const ticketMedio = vendasMes.length > 0 ? totalMes / vendasMes.length : 0;
  
  // Clientes ativos (visitaram nos últimos 30 dias)
  const clientesAtivos = clientes.filter((c) => {
    if (!c.ultimoVisita) return false;
    const diasAtras = new Date();
    diasAtras.setDate(diasAtras.getDate() - 30);
    return new Date(c.ultimoVisita) >= diasAtras;
  }).length;
  
  // Vendas por forma de pagamento
  const vendasPorPagamento = {
    dinheiro: vendasHoje.filter((v) => v.formaPagamento === 'dinheiro').reduce((acc, v) => acc + v.preco, 0),
    cartao: vendasHoje.filter((v) => v.formaPagamento === 'cartao').reduce((acc, v) => acc + v.preco, 0),
    pix: vendasHoje.filter((v) => v.formaPagamento === 'pix').reduce((acc, v) => acc + v.preco, 0),
  };

  // Vendas dos últimos 7 dias
  const vendasUltimos7Dias = (() => {
    const dias = [];
    for (let i = 6; i >= 0; i--) {
      const data = new Date();
      data.setDate(data.getDate() - i);
      const dataStr = data.toISOString().split('T')[0];
      const vendasDia = vendas.filter((v) => v.data === dataStr);
      const totalDia = vendasDia.reduce((acc, v) => acc + v.preco, 0);
      dias.push({
        data: data.toLocaleDateString('pt-BR', { weekday: 'short' }),
        total: totalDia,
        quantidade: vendasDia.length,
      });
    }
    return dias;
  })();

  // Top barbeiros do mês
  const topBarbeiros = barbeiros
    .map((b) => {
      const vendasBarbeiro = vendasMes.filter((v) => v.barbeiroId === b.id);
      return {
        nome: b.nome,
        total: vendasBarbeiro.reduce((acc, v) => acc + v.preco, 0),
        quantidade: vendasBarbeiro.length,
      };
    })
    .sort((a, b) => b.total - a.total)
    .slice(0, 5);

  // Serviços mais vendidos do mês
  const servicosMaisVendidos = servicos
    .map((s) => {
      const vendasServico = vendasMes.filter((v) => v.servicoId === s.id);
      return {
        nome: s.nome,
        quantidade: vendasServico.length,
        total: vendasServico.reduce((acc, v) => acc + v.preco, 0),
      };
    })
    .filter((s) => s.quantidade > 0)
    .sort((a, b) => b.quantidade - a.quantidade)
    .slice(0, 5);

  // Formatar moeda
  const formatPreco = (preco: number) => {
    return preco.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    });
  };

  // Calcular meta diária (exemplo: R$ 500)
  const metaDiaria = 500;
  const progressoMeta = Math.min((totalHoje / metaDiaria) * 100, 100);

  return (
    <div className="space-y-6">
      {/* Cards principais */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Total Hoje */}
        <Card className="bg-gradient-to-br from-primary/20 to-primary/5 border-primary/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Hoje</p>
                <p className="text-2xl font-bold text-primary">{formatPreco(totalHoje)}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {vendasHoje.length} {vendasHoje.length === 1 ? 'venda' : 'vendas'}
                </p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/20">
                <DollarSign className="h-6 w-6 text-primary" />
              </div>
            </div>
            
            {/* Progresso da meta */}
            <div className="mt-3">
              <div className="flex justify-between text-xs text-muted-foreground mb-1">
                <span>Meta diária</span>
                <span>{progressoMeta.toFixed(0)}%</span>
              </div>
              <Progress value={progressoMeta} className="h-1.5 bg-secondary" />
            </div>
          </CardContent>
        </Card>

        {/* Total Mês */}
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total do Mês</p>
                <p className="text-2xl font-bold text-foreground">{formatPreco(totalMes)}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {vendasMes.length} {vendasMes.length === 1 ? 'venda' : 'vendas'}
                </p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-green-500/20">
                <TrendingUp className="h-6 w-6 text-green-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Agendamentos */}
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Agendamentos Hoje</p>
                <p className="text-2xl font-bold text-foreground">{agendamentosHoje.length}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {agendamentosPendentes.length} pendentes
                </p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-500/20">
                <Calendar className="h-6 w-6 text-blue-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Lucro Estimado */}
        <Card className={`border-border ${lucroEstimado >= 0 ? 'bg-card' : 'bg-red-500/10'}`}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Lucro Estimado</p>
                <p className={`text-2xl font-bold ${lucroEstimado >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {formatPreco(lucroEstimado)}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Despesas: {formatPreco(totalDespesasMes)}
                </p>
              </div>
              <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${
                lucroEstimado >= 0 ? 'bg-green-500/20' : 'bg-red-500/20'
              }`}>
                {lucroEstimado >= 0 ? (
                  <ArrowUpRight className="h-6 w-6 text-green-400" />
                ) : (
                  <ArrowDownRight className="h-6 w-6 text-red-400" />
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Segunda linha de cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-500/20">
                <Activity className="h-5 w-5 text-purple-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Ticket Médio</p>
                <p className="text-lg font-bold text-foreground">{formatPreco(ticketMedio)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-500/20">
                <Users className="h-5 w-5 text-cyan-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Clientes Ativos</p>
                <p className="text-lg font-bold text-foreground">{clientesAtivos}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-500/20">
                <Scissors className="h-5 w-5 text-orange-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Serviços</p>
                <p className="text-lg font-bold text-foreground">{servicos.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-pink-500/20">
                <Users className="h-5 w-5 text-pink-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Barbeiros</p>
                <p className="text-lg font-bold text-foreground">{barbeiros.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Gráficos */}
      <div className="grid md:grid-cols-2 gap-4">
        {/* Gráfico de vendas */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              Vendas Últimos 7 Dias
            </CardTitle>
          </CardHeader>
          <CardContent>
            {vendasUltimos7Dias.some((d) => d.total > 0) ? (
              <ResponsiveContainer width="100%" height={200}>
                <AreaChart data={vendasUltimos7Dias}>
                  <defs>
                    <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#ffb400" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#ffb400" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                  <XAxis dataKey="data" stroke="#a0a0a0" fontSize={10} />
                  <YAxis stroke="#a0a0a0" fontSize={10} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1e1e1e',
                      border: '1px solid #333',
                      borderRadius: '8px',
                    }}
                    labelStyle={{ color: '#ffb400' }}
                    formatter={(value: number) => [formatPreco(value), 'Total']}
                  />
                  <Area
                    type="monotone"
                    dataKey="total"
                    stroke="#ffb400"
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#colorTotal)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-[200px] text-muted-foreground">
                Sem dados para exibir
              </div>
            )}
          </CardContent>
        </Card>

        {/* Formas de pagamento */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground flex items-center gap-2">
              <Wallet className="h-4 w-4 text-primary" />
              Pagamentos Hoje
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Dinheiro */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-500/20">
                    <DollarSign className="h-5 w-5 text-green-400" />
                  </div>
                  <div>
                    <p className="font-medium">Dinheiro</p>
                    <p className="text-sm text-muted-foreground">
                      {vendasHoje.filter((v) => v.formaPagamento === 'dinheiro').length} vendas
                    </p>
                  </div>
                </div>
                <p className="font-bold text-green-400">{formatPreco(vendasPorPagamento.dinheiro)}</p>
              </div>

              {/* Cartão */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-500/20">
                    <CreditCard className="h-5 w-5 text-blue-400" />
                  </div>
                  <div>
                    <p className="font-medium">Cartão</p>
                    <p className="text-sm text-muted-foreground">
                      {vendasHoje.filter((v) => v.formaPagamento === 'cartao').length} vendas
                    </p>
                  </div>
                </div>
                <p className="font-bold text-blue-400">{formatPreco(vendasPorPagamento.cartao)}</p>
              </div>

              {/* PIX */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-500/20">
                    <Smartphone className="h-5 w-5 text-purple-400" />
                  </div>
                  <div>
                    <p className="font-medium">PIX</p>
                    <p className="text-sm text-muted-foreground">
                      {vendasHoje.filter((v) => v.formaPagamento === 'pix').length} vendas
                    </p>
                  </div>
                </div>
                <p className="font-bold text-purple-400">{formatPreco(vendasPorPagamento.pix)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Top barbeiros e serviços */}
      <div className="grid md:grid-cols-2 gap-4">
        {/* Top barbeiros */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground flex items-center gap-2">
              <Users className="h-4 w-4 text-primary" />
              Top Barbeiros do Mês
            </CardTitle>
          </CardHeader>
          <CardContent>
            {topBarbeiros.length > 0 ? (
              <div className="space-y-3">
                {topBarbeiros.map((barbeiro, index) => (
                  <div key={barbeiro.nome} className="flex items-center gap-3">
                    <div className={`flex h-8 w-8 items-center justify-center rounded-full ${
                      index === 0 ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground'
                    }`}>
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">{barbeiro.nome}</p>
                      <p className="text-sm text-muted-foreground">{barbeiro.quantidade} vendas</p>
                    </div>
                    <p className="font-bold text-primary">{formatPreco(barbeiro.total)}</p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex items-center justify-center h-[150px] text-muted-foreground">
                Sem dados para exibir
              </div>
            )}
          </CardContent>
        </Card>

        {/* Serviços mais vendidos */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground flex items-center gap-2">
              <Scissors className="h-4 w-4 text-primary" />
              Serviços Mais Vendidos
            </CardTitle>
          </CardHeader>
          <CardContent>
            {servicosMaisVendidos.length > 0 ? (
              <div className="space-y-3">
                {servicosMaisVendidos.map((servico, index) => (
                  <div key={servico.nome} className="flex items-center gap-3">
                    <div className={`flex h-8 w-8 items-center justify-center rounded-full ${
                      index === 0 ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground'
                    }`}>
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">{servico.nome}</p>
                      <p className="text-sm text-muted-foreground">{servico.quantidade}x vendido</p>
                    </div>
                    <p className="font-bold text-primary">{formatPreco(servico.total)}</p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex items-center justify-center h-[150px] text-muted-foreground">
                Sem dados para exibir
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
