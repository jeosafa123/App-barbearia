'use client';

import { useState } from 'react';
import { DollarSign, CreditCard, Smartphone, Trash2, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import type { Venda, Servico, FormaPagamento } from '@/lib/types';

interface VendasTableProps {
  vendas: Venda[];
  servicos: Servico[];
  onRegistrarVenda: (servicoId: string, formaPagamento: FormaPagamento) => void;
  onDeleteVenda: (id: string) => void;
  barbeiroAtivo: boolean;
  barbeiroAtivoNome: string;
}

export default function VendasTable({
  vendas,
  servicos,
  onRegistrarVenda,
  onDeleteVenda,
  barbeiroAtivo,
  barbeiroAtivoNome,
}: VendasTableProps) {
  const [servicoSelecionado, setServicoSelecionado] = useState<Servico | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  const formatPreco = (preco: number) => {
    return preco.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    });
  };

  const handleSelectPagamento = (forma: FormaPagamento) => {
    if (servicoSelecionado) {
      onRegistrarVenda(servicoSelecionado.id, forma);
      setServicoSelecionado(null);
      setDialogOpen(false);
    }
  };

  const getFormaPagamentoIcon = (forma: FormaPagamento) => {
    switch (forma) {
      case 'dinheiro':
        return <DollarSign className="h-3 w-3" />;
      case 'cartao':
        return <CreditCard className="h-3 w-3" />;
      case 'pix':
        return <Smartphone className="h-3 w-3" />;
    }
  };

  const getFormaPagamentoBadge = (forma: FormaPagamento) => {
    const variants = {
      dinheiro: 'bg-green-600/20 text-green-400 border-green-600/30',
      cartao: 'bg-blue-600/20 text-blue-400 border-blue-600/30',
      pix: 'bg-purple-600/20 text-purple-400 border-purple-600/30',
    };
    return variants[forma];
  };

  // Calcular total do dia
  const totalDia = vendas.reduce((acc, venda) => acc + venda.preco, 0);

  // Serviço selecionado para dialog
  const handleServicoClick = (servico: Servico) => {
    if (barbeiroAtivo) {
      setServicoSelecionado(servico);
      setDialogOpen(true);
    }
  };

  return (
    <div className="space-y-4">
      {/* Header com total */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Clock className="h-4 w-4 text-primary" />
          <h2 className="text-sm font-medium text-muted-foreground">
            Vendas de Hoje
          </h2>
        </div>
        <div className="flex items-center gap-2 text-primary font-bold">
          <span>Total:</span>
          <span className="text-lg">{formatPreco(totalDia)}</span>
        </div>
      </div>

      {/* Serviços rápidos */}
      {barbeiroAtivo && (
        <div className="flex flex-wrap gap-2">
          {servicos.slice(0, 4).map((servico) => (
            <Button
              key={servico.id}
              size="sm"
              variant="outline"
              className="border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground"
              onClick={() => handleServicoClick(servico)}
            >
              {servico.nome} - {formatPreco(servico.preco)}
            </Button>
          ))}
        </div>
      )}

      {/* Tabela de vendas */}
      {vendas.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-8 text-center">
          <DollarSign className="mb-2 h-10 w-10 text-muted-foreground" />
          <p className="text-muted-foreground">Nenhuma venda registrada hoje</p>
          {barbeiroAtivo && (
            <p className="text-sm text-muted-foreground/70">
              Clique em um serviço para registrar uma venda
            </p>
          )}
        </div>
      ) : (
        <ScrollArea className="max-h-80 rounded-lg border border-border bg-card">
          <Table>
            <TableHeader>
              <TableRow className="border-border hover:bg-transparent">
                <TableHead className="text-muted-foreground">Hora</TableHead>
                <TableHead className="text-muted-foreground">Serviço</TableHead>
                <TableHead className="text-muted-foreground">Valor</TableHead>
                <TableHead className="text-muted-foreground">Pagamento</TableHead>
                <TableHead className="text-muted-foreground text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {vendas.map((venda) => (
                <TableRow
                  key={venda.id}
                  className="border-border hover:bg-secondary/50"
                >
                  <TableCell className="text-muted-foreground">
                    {venda.hora}
                  </TableCell>
                  <TableCell className="font-medium">{venda.servicoNome}</TableCell>
                  <TableCell className="text-primary font-semibold">
                    {formatPreco(venda.preco)}
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={`${getFormaPagamentoBadge(venda.formaPagamento)} flex items-center gap-1 w-fit`}
                    >
                      {getFormaPagamentoIcon(venda.formaPagamento)}
                      <span className="capitalize">{venda.formaPagamento}</span>
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                      onClick={() => onDeleteVenda(venda.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </ScrollArea>
      )}

      {/* Dialog para selecionar forma de pagamento */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle className="text-primary">Forma de Pagamento</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Selecione como o cliente vai pagar por{' '}
              <strong className="text-foreground">
                {servicoSelecionado?.nome} - {servicoSelecionado && formatPreco(servicoSelecionado.preco)}
              </strong>
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-3 gap-3 pt-4">
            <Button
              variant="outline"
              className="flex flex-col items-center gap-2 h-auto py-4 border-green-600/30 hover:bg-green-600/20 hover:text-green-400"
              onClick={() => handleSelectPagamento('dinheiro')}
            >
              <DollarSign className="h-6 w-6" />
              <span>Dinheiro</span>
            </Button>
            <Button
              variant="outline"
              className="flex flex-col items-center gap-2 h-auto py-4 border-blue-600/30 hover:bg-blue-600/20 hover:text-blue-400"
              onClick={() => handleSelectPagamento('cartao')}
            >
              <CreditCard className="h-6 w-6" />
              <span>Cartão</span>
            </Button>
            <Button
              variant="outline"
              className="flex flex-col items-center gap-2 h-auto py-4 border-purple-600/30 hover:bg-purple-600/20 hover:text-purple-400"
              onClick={() => handleSelectPagamento('pix')}
            >
              <Smartphone className="h-6 w-6" />
              <span>PIX</span>
            </Button>
          </div>
          <DialogFooter className="mt-4">
            <Button
              variant="outline"
              onClick={() => setDialogOpen(false)}
              className="border-border"
            >
              Cancelar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
