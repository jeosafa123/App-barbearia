'use client';

import { useState, useRef } from 'react';
import { 
  Settings, Download, Upload, Trash2, Database, 
  FileJson, AlertTriangle, Check, RefreshCw, Shield
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';
import type { BackupData } from '@/lib/types';

interface ConfiguracoesSectionProps {
  onExportData: () => BackupData;
  onImportData: (data: BackupData) => void;
  onClearData: () => void;
}

export default function ConfiguracoesSection({
  onExportData,
  onImportData,
  onClearData,
}: ConfiguracoesSectionProps) {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [importing, setImporting] = useState(false);

  // Exportar dados
  const handleExport = () => {
    try {
      const data = onExportData();
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `backup-barbearia-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast({
        title: 'Backup realizado!',
        description: 'Os dados foram exportados com sucesso.',
      });
    } catch (error) {
      toast({
        title: 'Erro ao exportar',
        description: 'Não foi possível exportar os dados.',
        variant: 'destructive',
      });
    }
  };

  // Importar dados
  const handleImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setImporting(true);
    try {
      const text = await file.text();
      const data = JSON.parse(text) as BackupData;

      // Validar estrutura básica
      if (!data.versao || !data.dataExportacao) {
        throw new Error('Formato de arquivo inválido');
      }

      onImportData(data);

      toast({
        title: 'Dados importados!',
        description: 'Os dados foram restaurados com sucesso.',
      });
    } catch (error) {
      toast({
        title: 'Erro ao importar',
        description: 'Arquivo inválido ou corrompido.',
        variant: 'destructive',
      });
    } finally {
      setImporting(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  // Calcular tamanho dos dados
  const calculateDataSize = () => {
    const data = onExportData();
    const size = new Blob([JSON.stringify(data)]).size;
    if (size < 1024) return `${size} B`;
    if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
    return `${(size / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-2">
        <Settings className="h-5 w-5 text-primary" />
        <h2 className="text-lg font-semibold text-foreground">Configurações</h2>
      </div>

      {/* Backup e Restauração */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-sm text-muted-foreground flex items-center gap-2">
            <Database className="h-4 w-4 text-primary" />
            Backup e Restauração
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Faça backup dos seus dados regularmente para evitar perda de informações.
            O arquivo de backup contém todos os dados da aplicação.
          </p>

          <div className="grid grid-cols-2 gap-4">
            {/* Exportar */}
            <Card className="bg-secondary/50 border-border">
              <CardContent className="p-4">
                <div className="flex flex-col items-center text-center">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/20 mb-3">
                    <Download className="h-6 w-6 text-primary" />
                  </div>
                  <p className="font-medium mb-1">Exportar Dados</p>
                  <p className="text-xs text-muted-foreground mb-3">
                    Tamanho: {calculateDataSize()}
                  </p>
                  <Button
                    onClick={handleExport}
                    className="bg-primary text-primary-foreground hover:bg-primary/90 w-full"
                  >
                    <FileJson className="h-4 w-4 mr-2" />
                    Fazer Backup
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Importar */}
            <Card className="bg-secondary/50 border-border">
              <CardContent className="p-4">
                <div className="flex flex-col items-center text-center">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-500/20 mb-3">
                    <Upload className="h-6 w-6 text-blue-400" />
                  </div>
                  <p className="font-medium mb-1">Importar Dados</p>
                  <p className="text-xs text-muted-foreground mb-3">
                    Restaure de um backup
                  </p>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".json"
                    onChange={handleImport}
                    className="hidden"
                    id="import-file"
                  />
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    disabled={importing}
                    variant="outline"
                    className="border-blue-400 text-blue-400 hover:bg-blue-400/20 w-full"
                  >
                    {importing ? (
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <Upload className="h-4 w-4 mr-2" />
                    )}
                    {importing ? 'Importando...' : 'Restaurar'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="flex items-start gap-2 p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/30">
            <AlertTriangle className="h-5 w-5 text-yellow-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-yellow-400">Atenção</p>
              <p className="text-xs text-muted-foreground">
                Ao restaurar um backup, os dados atuais serão substituídos. 
                Faça um backup antes de restaurar.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Informações do Sistema */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-sm text-muted-foreground flex items-center gap-2">
            <Shield className="h-4 w-4 text-primary" />
            Informações do Sistema
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex justify-between items-center py-2 border-b border-border">
              <span className="text-sm text-muted-foreground">Versão</span>
              <Badge variant="outline" className="border-primary text-primary">
                2.0.0
              </Badge>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-border">
              <span className="text-sm text-muted-foreground">Armazenamento</span>
              <span className="text-sm">Local (localStorage)</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-border">
              <span className="text-sm text-muted-foreground">Tema</span>
              <span className="text-sm">Escuro</span>
            </div>
            <div className="flex justify-between items-center py-2">
              <span className="text-sm text-muted-foreground">Última atualização</span>
              <span className="text-sm">{new Date().toLocaleDateString('pt-BR')}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Zona de Perigo */}
      <Card className="bg-red-500/5 border-red-500/30">
        <CardHeader>
          <CardTitle className="text-sm text-red-400 flex items-center gap-2">
            <AlertTriangle className="h-4 w-4" />
            Zona de Perigo
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-4">
            Esta ação é irreversível. Todos os dados serão permanentemente excluídos.
          </p>

          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" className="w-full">
                <Trash2 className="h-4 w-4 mr-2" />
                Limpar Todos os Dados
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent className="bg-card border-border">
              <AlertDialogHeader>
                <AlertDialogTitle className="text-foreground">
                  Tem certeza absoluta?
                </AlertDialogTitle>
                <AlertDialogDescription className="text-muted-foreground">
                  Esta ação não pode ser desfeita. Todos os dados serão permanentemente
                  excluídos, incluindo barbeiros, serviços, vendas, clientes e agendamentos.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel className="border-border">
                  Cancelar
                </AlertDialogCancel>
                <AlertDialogAction
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  onClick={onClearData}
                >
                  Sim, excluir tudo
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </CardContent>
      </Card>
    </div>
  );
}
