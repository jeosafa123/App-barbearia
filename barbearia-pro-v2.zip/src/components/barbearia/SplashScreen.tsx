'use client';

import { useEffect, useState } from 'react';
import { Scissors, Sparkles, Star } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

interface SplashScreenProps {
  onComplete: () => void;
  duration?: number;
}

export default function SplashScreen({ onComplete, duration = 2500 }: SplashScreenProps) {
  const [progress, setProgress] = useState(0);
  const [fadeOut, setFadeOut] = useState(false);
  const [showText, setShowText] = useState(false);

  useEffect(() => {
    // Animação da barra de progresso
    const startTime = Date.now();
    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const newProgress = Math.min((elapsed / duration) * 100, 100);
      setProgress(newProgress);

      if (newProgress >= 100) {
        clearInterval(interval);
        setFadeOut(true);
        setTimeout(onComplete, 400);
      }
    }, 30);

    // Mostrar texto com delay
    const textTimer = setTimeout(() => setShowText(true), 300);

    return () => {
      clearInterval(interval);
      clearTimeout(textTimer);
    };
  }, [duration, onComplete]);

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-background transition-opacity duration-400 ${
        fadeOut ? 'opacity-0' : 'opacity-100'
      }`}
    >
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
      </div>

      {/* Main content */}
      <div className="relative flex flex-col items-center">
        {/* Logo com animação */}
        <div className="relative mb-6">
          {/* Glow effect */}
          <div className="absolute inset-0 bg-primary/30 rounded-2xl blur-xl animate-pulse" />
          
          {/* Main icon container */}
          <div className="relative flex h-24 w-24 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-primary/70 shadow-2xl shadow-primary/30">
            <Scissors
              className="h-12 w-12 text-primary-foreground animate-scissors-cut"
              strokeWidth={2.5}
            />
          </div>
          
          {/* Sparkles */}
          <Sparkles className="absolute -right-2 -top-2 h-6 w-6 text-primary animate-pulse" />
          <Sparkles className="absolute -left-1 bottom-0 h-4 w-4 text-primary/60 animate-pulse delay-300" />
        </div>

        {/* Title */}
        <div className={`text-center transition-all duration-500 ${showText ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
          <h1 className="mb-2 text-3xl font-bold text-primary tracking-tight">
            Barbearia Pro
          </h1>
          <p className="text-muted-foreground text-sm tracking-wide">
            Sistema de Gestão
          </p>
        </div>

        {/* Decorative stars */}
        <div className="flex items-center gap-1 mt-4">
          <Star className="h-3 w-3 text-primary/60" fill="currentColor" />
          <Star className="h-4 w-4 text-primary" fill="currentColor" />
          <Star className="h-3 w-3 text-primary/60" fill="currentColor" />
        </div>
      </div>

      {/* Progress bar */}
      <div className="absolute bottom-12 w-72 px-4">
        <Progress value={progress} className="h-1 bg-secondary" />
        <p className="mt-2 text-center text-xs text-muted-foreground">
          {progress < 100 ? 'Carregando...' : 'Pronto!'}
        </p>
      </div>

      {/* Version */}
      <div className="absolute bottom-4 text-xs text-muted-foreground/50">
        v2.0.0
      </div>
    </div>
  );
}
