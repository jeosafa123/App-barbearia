'use client';

import { useState, useMemo } from 'react';
import { 
  User, Plus, Search, Phone, Mail, Calendar, 
  Edit2, Trash2, UserPlus, Star, Clock, DollarSign,
  Filter, MoreVertical
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import type { Cliente, Venda } from '@/lib/types';

interface ClientesSectionProps {
  clientes: Cliente[];
  vendas: Venda[];
  onAddCliente: (cliente: Omit<Cliente, 'id' | 'dataCadastro' | 'totalVisitas' | 'totalGasto'>) => void;
  onEditCliente: (id: string, cliente: Partial<Cliente>) => void;
  onDeleteCliente: (id: string) => void;
  onSelectCliente: (cliente: Cliente) => void;
}

export default function ClientesSection({
  clientes,
  vendas,
  onAddCliente,
  onEditCliente,
  onDeleteCliente,
  onSelectCliente,
}: ClientesSectionProps) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [detailsDialogOpen, setDetailsDialogOpen] = useState(false);
  const [clienteSelecionado, setClienteSelecionado] = useState<Cliente | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Form state
  const [formData, setFormData] = useState({
    nome: '',
    telefone: '',
    email: '',
    dataNascimento: '',
    observacoes: '',
  });

  const resetForm = () => {
    setFormData({
      nome: '',
      telefone: '',
      email: '',
      dataNascimento: '',
      observacoes: '',
    });
  };

  const handleAddCliente = () => {
    if (formData.nome.trim() && formData.telefone.trim()) {
      onAddCliente({
        nome: formData.nome.trim(),
        telefone: formData.telefone.trim(),
        email: formData.email.trim() || undefined,
        dataNascimento: formData.dataNascimento || undefined,
        observacoes: formData.observacoes.trim() || undefined,
      });
      resetForm();
      setDialogOpen(false);
    }
  };

  const handleEditCliente = () => {
    if (clienteSelecionado && formData.nome.trim() && formData.telefone.trim()) {
      onEditCliente(clienteSelecionado.id, {
        nome: formData.nome.trim(),
        telefone: formData.telefone.trim(),
        email: formData.email.trim() || undefined,
        dataNascimento: formData.dataNascimento || undefined,
        observacoes: formData.observacoes.trim() || undefined,
      });
      resetForm();
      setClienteSelecionado(null);
      setEditDialogOpen(false);
    }
  };

  const openEditDialog = (cliente: Cliente) => {
    setClienteSelecionado(cliente);
    setFormData({
      nome: cliente.nome,
      telefone: cliente.telefone,
      email: cliente.email || '',
      dataNascimento: cliente.dataNascimento || '',
      observacoes: cliente.observacoes || '',
    });
    setEditDialogOpen(true);
  };

  const openDetailsDialog = (cliente: Cliente) => {
    setClienteSelecionado(cliente);
    setDetailsDialogOpen(true);
  };

  // Filtrar clientes
  const clientesFiltrados = useMemo(() => {
    if (!searchTerm.trim()) return clientes;
    const term = searchTerm.toLowerCase();
    return clientes.filter(
      (c) =>
        c.nome.toLowerCase().includes(term) ||
        c.telefone.includes(term) ||
        c.email?.toLowerCase().includes(term)
    );
  }, [clientes, searchTerm]);

  // Histórico do cliente
  const getHistoricoCliente = (clienteId: string) => {
    return vendas.filter((v) => v.clienteId === clienteId);
  };

  // Formatar moeda
  const formatPreco = (preco: number) => {
    return preco.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    });
  };

  // Formatar data
  const formatData = (data: string) => {
    return new Date(data).toLocaleDateString('pt-BR');
  };

  // Clientes frequentes (mais de 5 visitas)
  const clientesFrequentes = clientes.filter((c) => c.totalVisitas >= 5);

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
        <div className="flex items-center gap-2">
          <User className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold text-foreground">Clientes</h2>
          {clientesFrequentes.length > 0 && (
            <Badge variant="outline" className="border-primary text-primary">
              <Star className="h-3 w-3 mr-1" />
              {clientesFrequentes.length} frequentes
            </Badge>
          )}
        </div>
        
        <div className="flex gap-2 w-full sm:w-auto">
          <div className="relative flex-1 sm:flex-initial">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar cliente..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-full sm:w-64 bg-secondary border-border"
            />
          </div>
          
          <Button
            onClick={() => setDialogOpen(true)}
            className="bg-primary text-primary-foreground hover:bg-primary/90"
          >
            <Plus className="h-4 w-4 mr-1" />
            <span className="hidden sm:inline">Novo</span>
          </Button>
        </div>
      </div>

      {/* Lista de clientes */}
      {clientesFiltrados.length === 0 ? (
        <Card className="border-dashed border-border bg-card/50">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <UserPlus className="mb-4 h-12 w-12 text-muted-foreground" />
            <p className="text-lg text-muted-foreground">
              {searchTerm ? 'Nenhum cliente encontrado' : 'Nenhum cliente cadastrado'}
            </p>
            <p className="text-sm text-muted-foreground/70 mt-1">
              {searchTerm ? 'Tente outra busca' : 'Clique em "Novo" para adicionar'}
            </p>
          </CardContent>
        </Card>
      ) : (
        <ScrollArea className="max-h-[500px]">
          <div className="grid gap-3 pr-4">
            {clientesFiltrados.map((cliente) => (
              <Card
                key={cliente.id}
                className="group cursor-pointer transition-all duration-200 hover:shadow-lg hover:shadow-primary/10 border-border bg-card hover:border-primary/50"
                onClick={() => openDetailsDialog(cliente)}
              >
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    {/* Avatar */}
                    <div className={`flex h-12 w-12 items-center justify-center rounded-full ${
                      cliente.totalVisitas >= 5 ? 'bg-primary/20' : 'bg-secondary'
                    }`}>
                      {cliente.totalVisitas >= 5 ? (
                        <Star className="h-6 w-6 text-primary" />
                      ) : (
                        <User className="h-6 w-6 text-muted-foreground" />
                      )}
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-medium text-foreground truncate">
                          {cliente.nome}
                        </p>
                        {cliente.totalVisitas >= 5 && (
                          <Badge variant="outline" className="text-xs border-primary text-primary">
                            VIP
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex flex-wrap gap-3 mt-1 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Phone className="h-3 w-3" />
                          {cliente.telefone}
                        </span>
                        {cliente.email && (
                          <span className="flex items-center gap-1">
                            <Mail className="h-3 w-3" />
                            {cliente.email}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Stats */}
                    <div className="hidden sm:flex items-center gap-4 text-sm">
                      <div className="text-center">
                        <p className="font-bold text-foreground">{cliente.totalVisitas}</p>
                        <p className="text-xs text-muted-foreground">visitas</p>
                      </div>
                      <div className="text-center">
                        <p className="font-bold text-primary">{formatPreco(cliente.totalGasto)}</p>
                        <p className="text-xs text-muted-foreground">total</p>
                      </div>
                    </div>

                    {/* Actions */}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-muted-foreground hover:text-foreground"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="bg-card border-border">
                        <DropdownMenuItem
                          onClick={(e) => {
                            e.stopPropagation();
                            openEditDialog(cliente);
                          }}
                          className="cursor-pointer"
                        >
                          <Edit2 className="h-4 w-4 mr-2" />
                          Editar
                        </DropdownMenuItem>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <DropdownMenuItem
                              onClick={(e) => e.stopPropagation()}
                              className="text-destructive focus:text-destructive cursor-pointer"
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              Excluir
                            </DropdownMenuItem>
                          </AlertDialogTrigger>
                          <AlertDialogContent className="bg-card border-border" onClick={(e) => e.stopPropagation()}>
                            <AlertDialogHeader>
                              <AlertDialogTitle className="text-foreground">
                                Excluir Cliente
                              </AlertDialogTitle>
                              <AlertDialogDescription className="text-muted-foreground">
                                Tem certeza que deseja excluir <strong>{cliente.nome}</strong>?
                                Esta ação não pode ser desfeita.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel className="border-border">
                                Cancelar
                              </AlertDialogCancel>
                              <AlertDialogAction
                                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                onClick={() => onDeleteCliente(cliente.id)}
                              >
                                Excluir
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </ScrollArea>
      )}

      {/* Dialog Adicionar Cliente */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle className="text-primary">Novo Cliente</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <Input
              placeholder="Nome completo *"
              value={formData.nome}
              onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
              className="border-border bg-secondary focus:border-primary"
            />
            <Input
              placeholder="Telefone *"
              value={formData.telefone}
              onChange={(e) => setFormData({ ...formData, telefone: e.target.value })}
              className="border-border bg-secondary focus:border-primary"
            />
            <Input
              placeholder="E-mail"
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="border-border bg-secondary focus:border-primary"
            />
            <Input
              placeholder="Data de nascimento"
              type="date"
              value={formData.dataNascimento}
              onChange={(e) => setFormData({ ...formData, dataNascimento: e.target.value })}
              className="border-border bg-secondary focus:border-primary"
            />
            <Input
              placeholder="Observações"
              value={formData.observacoes}
              onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
              className="border-border bg-secondary focus:border-primary"
            />
          </div>
          <DialogFooter className="mt-4">
            <Button
              variant="outline"
              onClick={() => {
                resetForm();
                setDialogOpen(false);
              }}
              className="border-border"
            >
              Cancelar
            </Button>
            <Button
              onClick={handleAddCliente}
              disabled={!formData.nome.trim() || !formData.telefone.trim()}
              className="bg-primary text-primary-foreground hover:bg-primary/90"
            >
              Adicionar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog Editar Cliente */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle className="text-primary">Editar Cliente</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <Input
              placeholder="Nome completo *"
              value={formData.nome}
              onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
              className="border-border bg-secondary focus:border-primary"
            />
            <Input
              placeholder="Telefone *"
              value={formData.telefone}
              onChange={(e) => setFormData({ ...formData, telefone: e.target.value })}
              className="border-border bg-secondary focus:border-primary"
            />
            <Input
              placeholder="E-mail"
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="border-border bg-secondary focus:border-primary"
            />
            <Input
              placeholder="Data de nascimento"
              type="date"
              value={formData.dataNascimento}
              onChange={(e) => setFormData({ ...formData, dataNascimento: e.target.value })}
              className="border-border bg-secondary focus:border-primary"
            />
            <Input
              placeholder="Observações"
              value={formData.observacoes}
              onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
              className="border-border bg-secondary focus:border-primary"
            />
          </div>
          <DialogFooter className="mt-4">
            <Button
              variant="outline"
              onClick={() => {
                resetForm();
                setClienteSelecionado(null);
                setEditDialogOpen(false);
              }}
              className="border-border"
            >
              Cancelar
            </Button>
            <Button
              onClick={handleEditCliente}
              disabled={!formData.nome.trim() || !formData.telefone.trim()}
              className="bg-primary text-primary-foreground hover:bg-primary/90"
            >
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog Detalhes do Cliente */}
      <Dialog open={detailsDialogOpen} onOpenChange={setDetailsDialogOpen}>
        <DialogContent className="bg-card border-border max-w-md">
          <DialogHeader>
            <DialogTitle className="text-primary flex items-center gap-2">
              {clienteSelecionado?.totalVisitas && clienteSelecionado.totalVisitas >= 5 && (
                <Star className="h-5 w-5" />
              )}
              {clienteSelecionado?.nome}
            </DialogTitle>
          </DialogHeader>
          
          {clienteSelecionado && (
            <div className="space-y-4 pt-4">
              {/* Info do cliente */}
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center gap-2 text-sm">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <span>{clienteSelecionado.telefone}</span>
                </div>
                {clienteSelecionado.email && (
                  <div className="flex items-center gap-2 text-sm">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <span className="truncate">{clienteSelecionado.email}</span>
                  </div>
                )}
                {clienteSelecionado.dataNascimento && (
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span>{formatData(clienteSelecionado.dataNascimento)}</span>
                  </div>
                )}
                <div className="flex items-center gap-2 text-sm">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span>Cliente desde {formatData(clienteSelecionado.dataCadastro)}</span>
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 gap-3">
                <Card className="bg-secondary/50 border-border">
                  <CardContent className="p-4 text-center">
                    <p className="text-2xl font-bold text-foreground">
                      {clienteSelecionado.totalVisitas}
                    </p>
                    <p className="text-xs text-muted-foreground">Total de visitas</p>
                  </CardContent>
                </Card>
                <Card className="bg-primary/10 border-primary/30">
                  <CardContent className="p-4 text-center">
                    <p className="text-2xl font-bold text-primary">
                      {formatPreco(clienteSelecionado.totalGasto)}
                    </p>
                    <p className="text-xs text-muted-foreground">Total gasto</p>
                  </CardContent>
                </Card>
              </div>

              {/* Últimas visitas */}
              <div>
                <h3 className="text-sm font-medium text-muted-foreground mb-2">
                  Últimas visitas
                </h3>
                {getHistoricoCliente(clienteSelecionado.id).length > 0 ? (
                  <ScrollArea className="max-h-40">
                    <div className="space-y-2">
                      {getHistoricoCliente(clienteSelecionado.id)
                        .slice(0, 5)
                        .map((venda) => (
                          <div
                            key={venda.id}
                            className="flex items-center justify-between p-2 rounded-lg bg-secondary/50"
                          >
                            <div>
                              <p className="text-sm font-medium">{venda.servicoNome}</p>
                              <p className="text-xs text-muted-foreground">
                                {venda.data} às {venda.hora}
                              </p>
                            </div>
                            <p className="font-bold text-primary">
                              {formatPreco(venda.preco)}
                            </p>
                          </div>
                        ))}
                    </div>
                  </ScrollArea>
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    Nenhuma visita registrada
                  </p>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
