'use client';

import { useState } from 'react';
import { Plus, Edit2, Trash2, DollarSign, Scissors } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import type { Servico } from '@/lib/types';

interface ServicosGridProps {
  servicos: Servico[];
  onAddServico: (nome: string, preco: number) => void;
  onEditServico: (id: string, nome: string, preco: number) => void;
  onDeleteServico: (id: string) => void;
  onSelectServico: (servico: Servico) => void;
  barbeiroAtivo: boolean;
}

export default function ServicosGrid({
  servicos,
  onAddServico,
  onEditServico,
  onDeleteServico,
  onSelectServico,
  barbeiroAtivo,
}: ServicosGridProps) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [servicoNome, setServicoNome] = useState('');
  const [servicoPreco, setServicoPreco] = useState('');
  const [servicoEditando, setServicoEditando] = useState<Servico | null>(null);

  const handleAddServico = () => {
    const preco = parseFloat(servicoPreco.replace(',', '.'));
    if (servicoNome.trim() && !isNaN(preco) && preco > 0) {
      onAddServico(servicoNome.trim(), preco);
      setServicoNome('');
      setServicoPreco('');
      setDialogOpen(false);
    }
  };

  const handleEditServico = () => {
    if (servicoEditando) {
      const preco = parseFloat(servicoPreco.replace(',', '.'));
      if (servicoNome.trim() && !isNaN(preco) && preco > 0) {
        onEditServico(servicoEditando.id, servicoNome.trim(), preco);
        setServicoNome('');
        setServicoPreco('');
        setServicoEditando(null);
        setEditDialogOpen(false);
      }
    }
  };

  const openEditDialog = (servico: Servico) => {
    setServicoEditando(servico);
    setServicoNome(servico.nome);
    setServicoPreco(servico.preco.toFixed(2).replace('.', ','));
    setEditDialogOpen(true);
  };

  const formatPreco = (preco: number) => {
    return preco.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    });
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Scissors className="h-4 w-4 text-primary" />
          <h2 className="text-sm font-medium text-muted-foreground">Serviços</h2>
        </div>
        
        {/* Dialog para adicionar serviço */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button
              size="sm"
              variant="outline"
              className="border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground"
            >
              <Plus className="mr-1 h-4 w-4" />
              Serviço
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border">
            <DialogHeader>
              <DialogTitle className="text-primary">Novo Serviço</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <Input
                placeholder="Nome do serviço"
                value={servicoNome}
                onChange={(e) => setServicoNome(e.target.value)}
                className="border-border bg-secondary focus:border-primary"
              />
              <Input
                placeholder="Preço (ex: 35,00)"
                value={servicoPreco}
                onChange={(e) => setServicoPreco(e.target.value)}
                className="border-border bg-secondary focus:border-primary"
              />
            </div>
            <DialogFooter className="mt-4">
              <Button
                variant="outline"
                onClick={() => setDialogOpen(false)}
                className="border-border"
              >
                Cancelar
              </Button>
              <Button
                onClick={handleAddServico}
                className="bg-primary text-primary-foreground hover:bg-primary/90"
              >
                Adicionar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Grid de serviços */}
      {servicos.filter(s => s.ativo !== false).length === 0 ? (
        <Card className="border-dashed border-border bg-card/50">
          <CardContent className="flex flex-col items-center justify-center py-8">
            <Scissors className="mb-2 h-10 w-10 text-muted-foreground" />
            <p className="text-center text-muted-foreground">
              Nenhum serviço cadastrado
            </p>
            <p className="text-sm text-muted-foreground/70">
              Clique em "+ Serviço" para adicionar
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
          {servicos.filter(s => s.ativo !== false).map((servico) => (
            <Card
              key={servico.id}
              className={`group relative overflow-hidden transition-all duration-200 ${
                barbeiroAtivo
                  ? 'cursor-pointer hover:scale-[1.02] hover:shadow-lg hover:shadow-primary/20 border-border bg-card hover:border-primary'
                  : 'opacity-60 border-border bg-card'
              }`}
              onClick={() => barbeiroAtivo && onSelectServico(servico)}
            >
              {/* Efeito de brilho no hover */}
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity animate-shimmer pointer-events-none" />
              
              <CardHeader className="p-3 pb-0">
                <CardTitle className="text-sm font-medium text-foreground truncate">
                  {servico.nome}
                </CardTitle>
              </CardHeader>
              <CardContent className="p-3 pt-1">
                <div className="flex items-center gap-1 text-primary font-bold">
                  <DollarSign className="h-4 w-4" />
                  <span>{formatPreco(servico.preco)}</span>
                </div>

                {/* Ações do card */}
                <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 bg-background/80 backdrop-blur-sm text-muted-foreground hover:text-primary"
                    onClick={(e) => {
                      e.stopPropagation();
                      openEditDialog(servico);
                    }}
                  >
                    <Edit2 className="h-3 w-3" />
                  </Button>
                  
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 bg-background/80 backdrop-blur-sm text-muted-foreground hover:text-destructive"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent className="bg-card border-border">
                      <AlertDialogHeader>
                        <AlertDialogTitle className="text-foreground">
                          Excluir Serviço
                        </AlertDialogTitle>
                        <AlertDialogDescription className="text-muted-foreground">
                          Tem certeza que deseja excluir <strong>{servico.nome}</strong>?
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel className="border-border">
                          Cancelar
                        </AlertDialogCancel>
                        <AlertDialogAction
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          onClick={() => onDeleteServico(servico.id)}
                        >
                          Excluir
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Aviso se não há barbeiro ativo */}
      {!barbeiroAtivo && servicos.length > 0 && (
        <p className="text-center text-sm text-muted-foreground">
          Selecione um barbeiro para registrar vendas
        </p>
      )}

      {/* Dialog para editar serviço */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle className="text-primary">Editar Serviço</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <Input
              placeholder="Nome do serviço"
              value={servicoNome}
              onChange={(e) => setServicoNome(e.target.value)}
              className="border-border bg-secondary focus:border-primary"
            />
            <Input
              placeholder="Preço (ex: 35,00)"
              value={servicoPreco}
              onChange={(e) => setServicoPreco(e.target.value)}
              className="border-border bg-secondary focus:border-primary"
            />
          </div>
          <DialogFooter className="mt-4">
            <Button
              variant="outline"
              onClick={() => setEditDialogOpen(false)}
              className="border-border"
            >
              Cancelar
            </Button>
            <Button
              onClick={handleEditServico}
              className="bg-primary text-primary-foreground hover:bg-primary/90"
            >
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
