'use client';

import { useState, useMemo } from 'react';
import { 
  Receipt, Plus, Search, DollarSign, Calendar, 
  Edit2, Trash2, Filter, TrendingDown, CreditCard,
  Check, AlertTriangle, RefreshCw
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import type { Despesa, CategoriaDespesa } from '@/lib/types';

interface DespesasSectionProps {
  despesas: Despesa[];
  onAddDespesa: (despesa: Omit<Despesa, 'id'>) => void;
  onEditDespesa: (id: string, despesa: Partial<Despesa>) => void;
  onDeleteDespesa: (id: string) => void;
  onMarcarPaga: (id: string) => void;
}

const CATEGORIAS: { value: CategoriaDespesa; label: string; icon: string }[] = [
  { value: 'aluguel', label: 'Aluguel', icon: '🏠' },
  { value: 'agua', label: 'Água', icon: '💧' },
  { value: 'luz', label: 'Energia', icon: '⚡' },
  { value: 'internet', label: 'Internet', icon: '📶' },
  { value: 'produtos', label: 'Produtos', icon: '🧴' },
  { value: 'equipamentos', label: 'Equipamentos', icon: '🔧' },
  { value: 'salario', label: 'Salários', icon: '💰' },
  { value: 'comissao', label: 'Comissões', icon: '💸' },
  { value: 'marketing', label: 'Marketing', icon: '📢' },
  { value: 'manutencao', label: 'Manutenção', icon: '🛠️' },
  { value: 'outros', label: 'Outros', icon: '📦' },
];

const getCategoriaInfo = (categoria: CategoriaDespesa) => {
  return CATEGORIAS.find((c) => c.value === categoria) || CATEGORIAS[10];
};

export default function DespesasSection({
  despesas,
  onAddDespesa,
  onEditDespesa,
  onDeleteDespesa,
  onMarcarPaga,
}: DespesasSectionProps) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [despesaEditando, setDespesaEditando] = useState<Despesa | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filtroCategoria, setFiltroCategoria] = useState<string>('todas');
  const [filtroStatus, setFiltroStatus] = useState<'todas' | 'pagas' | 'pendentes'>('todas');
  
  // Form state
  const [formData, setFormData] = useState({
    descricao: '',
    valor: '',
    categoria: 'outros' as CategoriaDespesa,
    data: new Date().toISOString().split('T')[0],
    dataVencimento: '',
    paga: false,
    observacao: '',
    recorrente: false,
    frequencia: 'mensal' as 'diaria' | 'semanal' | 'mensal' | 'anual',
  });

  const resetForm = () => {
    setFormData({
      descricao: '',
      valor: '',
      categoria: 'outros',
      data: new Date().toISOString().split('T')[0],
      dataVencimento: '',
      paga: false,
      observacao: '',
      recorrente: false,
      frequencia: 'mensal',
    });
  };

  const handleAddDespesa = () => {
    const valor = parseFloat(formData.valor.replace(',', '.'));
    if (formData.descricao.trim() && !isNaN(valor) && valor > 0) {
      onAddDespesa({
        descricao: formData.descricao.trim(),
        valor,
        categoria: formData.categoria,
        data: formData.data,
        dataVencimento: formData.dataVencimento || undefined,
        paga: formData.paga,
        observacao: formData.observacao.trim() || undefined,
        recorrente: formData.recorrente,
        frequencia: formData.recorrente ? formData.frequencia : undefined,
      });
      resetForm();
      setDialogOpen(false);
    }
  };

  const handleEditDespesa = () => {
    const valor = parseFloat(formData.valor.replace(',', '.'));
    if (despesaEditando && formData.descricao.trim() && !isNaN(valor) && valor > 0) {
      onEditDespesa(despesaEditando.id, {
        descricao: formData.descricao.trim(),
        valor,
        categoria: formData.categoria,
        data: formData.data,
        dataVencimento: formData.dataVencimento || undefined,
        paga: formData.paga,
        observacao: formData.observacao.trim() || undefined,
        recorrente: formData.recorrente,
        frequencia: formData.recorrente ? formData.frequencia : undefined,
      });
      resetForm();
      setDespesaEditando(null);
      setEditDialogOpen(false);
    }
  };

  const openEditDialog = (despesa: Despesa) => {
    setDespesaEditando(despesa);
    setFormData({
      descricao: despesa.descricao,
      valor: despesa.valor.toFixed(2).replace('.', ','),
      categoria: despesa.categoria,
      data: despesa.data,
      dataVencimento: despesa.dataVencimento || '',
      paga: despesa.paga,
      observacao: despesa.observacao || '',
      recorrente: despesa.recorrente,
      frequencia: despesa.frequencia || 'mensal',
    });
    setEditDialogOpen(true);
  };

  // Filtrar despesas
  const despesasFiltradas = useMemo(() => {
    return despesas.filter((d) => {
      const matchSearch = !searchTerm.trim() || 
        d.descricao.toLowerCase().includes(searchTerm.toLowerCase());
      const matchCategoria = filtroCategoria === 'todas' || d.categoria === filtroCategoria;
      const matchStatus = filtroStatus === 'todas' || 
        (filtroStatus === 'pagas' && d.paga) || 
        (filtroStatus === 'pendentes' && !d.paga);
      return matchSearch && matchCategoria && matchStatus;
    }).sort((a, b) => new Date(b.data).getTime() - new Date(a.data).getTime());
  }, [despesas, searchTerm, filtroCategoria, filtroStatus]);

  // Cálculos
  const stats = useMemo(() => {
    const mesAtual = new Date().toISOString().slice(0, 7);
    const despesasMes = despesas.filter((d) => d.data.startsWith(mesAtual));
    
    return {
      totalMes: despesasMes.reduce((acc, d) => acc + d.valor, 0),
      pagas: despesasMes.filter((d) => d.paga).reduce((acc, d) => acc + d.valor, 0),
      pendentes: despesasMes.filter((d) => !d.paga).reduce((acc, d) => acc + d.valor, 0),
      totalRecorrentes: despesas.filter((d) => d.recorrente).reduce((acc, d) => acc + d.valor, 0),
    };
  }, [despesas]);

  // Agrupar por categoria
  const despesasPorCategoria = useMemo(() => {
    const map = new Map<CategoriaDespesa, number>();
    despesasFiltradas.forEach((d) => {
      const current = map.get(d.categoria) || 0;
      map.set(d.categoria, current + d.valor);
    });
    return Array.from(map.entries())
      .map(([categoria, total]) => ({ categoria, total }))
      .sort((a, b) => b.total - a.total);
  }, [despesasFiltradas]);

  // Formatar moeda
  const formatPreco = (preco: number) => {
    return preco.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    });
  };

  // Formatar data
  const formatData = (data: string) => {
    return new Date(data + 'T12:00:00').toLocaleDateString('pt-BR');
  };

  // Verificar se está vencida
  const isVencida = (despesa: Despesa) => {
    if (despesa.paga || !despesa.dataVencimento) return false;
    const hoje = new Date().toISOString().split('T')[0];
    return despesa.dataVencimento < hoje;
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
        <div className="flex items-center gap-2">
          <Receipt className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold text-foreground">Despesas</h2>
        </div>
        
        <Button
          onClick={() => setDialogOpen(true)}
          className="bg-primary text-primary-foreground hover:bg-primary/90"
        >
          <Plus className="h-4 w-4 mr-1" />
          Nova Despesa
        </Button>
      </div>

      {/* Cards de resumo */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-500/20">
                <TrendingDown className="h-5 w-5 text-red-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Total do Mês</p>
                <p className="text-lg font-bold text-foreground">
                  {formatPreco(stats.totalMes)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-500/20">
                <Check className="h-5 w-5 text-green-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Pagas</p>
                <p className="text-lg font-bold text-green-400">
                  {formatPreco(stats.pagas)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-yellow-500/20">
                <AlertTriangle className="h-5 w-5 text-yellow-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Pendentes</p>
                <p className="text-lg font-bold text-yellow-400">
                  {formatPreco(stats.pendentes)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-500/20">
                <RefreshCw className="h-5 w-5 text-blue-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Recorrentes</p>
                <p className="text-lg font-bold text-blue-400">
                  {formatPreco(stats.totalRecorrentes)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filtros */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar despesa..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-secondary border-border"
          />
        </div>
        
        <Select value={filtroCategoria} onValueChange={setFiltroCategoria}>
          <SelectTrigger className="w-full sm:w-40 bg-secondary border-border">
            <SelectValue placeholder="Categoria" />
          </SelectTrigger>
          <SelectContent className="bg-card border-border">
            <SelectItem value="todas">Todas</SelectItem>
            {CATEGORIAS.map((cat) => (
              <SelectItem key={cat.value} value={cat.value}>
                {cat.icon} {cat.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        <Select 
          value={filtroStatus} 
          onValueChange={(v) => setFiltroStatus(v as 'todas' | 'pagas' | 'pendentes')}
        >
          <SelectTrigger className="w-full sm:w-36 bg-secondary border-border">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent className="bg-card border-border">
            <SelectItem value="todas">Todas</SelectItem>
            <SelectItem value="pagas">Pagas</SelectItem>
            <SelectItem value="pendentes">Pendentes</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Lista de despesas */}
      {despesasFiltradas.length === 0 ? (
        <Card className="border-dashed border-border bg-card/50">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Receipt className="mb-4 h-12 w-12 text-muted-foreground" />
            <p className="text-lg text-muted-foreground">
              {searchTerm || filtroCategoria !== 'todas' || filtroStatus !== 'todas'
                ? 'Nenhuma despesa encontrada'
                : 'Nenhuma despesa cadastrada'}
            </p>
            <p className="text-sm text-muted-foreground/70 mt-1">
              Clique em "Nova Despesa" para começar
            </p>
          </CardContent>
        </Card>
      ) : (
        <ScrollArea className="max-h-[400px]">
          <div className="space-y-2 pr-4">
            {despesasFiltradas.map((despesa) => {
              const catInfo = getCategoriaInfo(despesa.categoria);
              const vencida = isVencida(despesa);
              
              return (
                <Card
                  key={despesa.id}
                  className={`transition-all duration-200 border-border bg-card hover:border-primary/50 ${
                    vencida ? 'border-red-500/50' : ''
                  }`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      {/* Ícone da categoria */}
                      <div className={`flex h-12 w-12 items-center justify-center rounded-lg ${
                        despesa.paga ? 'bg-green-500/20' : vencida ? 'bg-red-500/20' : 'bg-secondary'
                      }`}>
                        <span className="text-2xl">{catInfo.icon}</span>
                      </div>

                      {/* Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="font-medium text-foreground truncate">
                            {despesa.descricao}
                          </p>
                          {despesa.recorrente && (
                            <Badge variant="outline" className="text-xs border-blue-400 text-blue-400">
                              <RefreshCw className="h-3 w-3 mr-1" />
                              Recorrente
                            </Badge>
                          )}
                        </div>
                        
                        <div className="flex flex-wrap gap-3 mt-1 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {formatData(despesa.data)}
                          </span>
                          {despesa.dataVencimento && (
                            <span className={`flex items-center gap-1 ${vencida ? 'text-red-400' : ''}`}>
                              Vence: {formatData(despesa.dataVencimento)}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Valor */}
                      <div className="text-right">
                        <p className={`text-lg font-bold ${
                          despesa.paga ? 'text-green-400' : vencida ? 'text-red-400' : 'text-foreground'
                        }`}>
                          {formatPreco(despesa.valor)}
                        </p>
                        <Badge
                          variant="outline"
                          className={
                            despesa.paga 
                              ? 'border-green-400 text-green-400' 
                              : vencida 
                                ? 'border-red-400 text-red-400'
                                : 'border-yellow-400 text-yellow-400'
                          }
                        >
                          {despesa.paga ? 'Pago' : vencida ? 'Vencida' : 'Pendente'}
                        </Badge>
                      </div>

                      {/* Ações */}
                      <div className="flex gap-1">
                        {!despesa.paga && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-green-400 hover:bg-green-400/20"
                            onClick={() => onMarcarPaga(despesa.id)}
                            title="Marcar como paga"
                          >
                            <Check className="h-4 w-4" />
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-muted-foreground hover:text-primary"
                          onClick={() => openEditDialog(despesa)}
                        >
                          <Edit2 className="h-4 w-4" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent className="bg-card border-border">
                            <AlertDialogHeader>
                              <AlertDialogTitle className="text-foreground">
                                Excluir Despesa
                              </AlertDialogTitle>
                              <AlertDialogDescription className="text-muted-foreground">
                                Tem certeza que deseja excluir <strong>{despesa.descricao}</strong>?
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel className="border-border">
                                Cancelar
                              </AlertDialogCancel>
                              <AlertDialogAction
                                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                onClick={() => onDeleteDespesa(despesa.id)}
                              >
                                Excluir
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </ScrollArea>
      )}

      {/* Dialog Nova Despesa */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-card border-border max-w-md">
          <DialogHeader>
            <DialogTitle className="text-primary">Nova Despesa</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 pt-4">
            <Input
              placeholder="Descrição *"
              value={formData.descricao}
              onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
              className="border-border bg-secondary focus:border-primary"
            />
            
            <div className="grid grid-cols-2 gap-3">
              <Input
                placeholder="Valor *"
                value={formData.valor}
                onChange={(e) => setFormData({ ...formData, valor: e.target.value })}
                className="border-border bg-secondary focus:border-primary"
              />
              
              <Select
                value={formData.categoria}
                onValueChange={(v) => setFormData({ ...formData, categoria: v as CategoriaDespesa })}
              >
                <SelectTrigger className="bg-secondary border-border">
                  <SelectValue placeholder="Categoria" />
                </SelectTrigger>
                <SelectContent className="bg-card border-border">
                  {CATEGORIAS.map((cat) => (
                    <SelectItem key={cat.value} value={cat.value}>
                      {cat.icon} {cat.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <label className="text-sm text-muted-foreground">Data</label>
                <Input
                  type="date"
                  value={formData.data}
                  onChange={(e) => setFormData({ ...formData, data: e.target.value })}
                  className="border-border bg-secondary focus:border-primary"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm text-muted-foreground">Vencimento</label>
                <Input
                  type="date"
                  value={formData.dataVencimento}
                  onChange={(e) => setFormData({ ...formData, dataVencimento: e.target.value })}
                  className="border-border bg-secondary focus:border-primary"
                />
              </div>
            </div>

            <Input
              placeholder="Observação (opcional)"
              value={formData.observacao}
              onChange={(e) => setFormData({ ...formData, observacao: e.target.value })}
              className="border-border bg-secondary focus:border-primary"
            />

            <div className="flex items-center gap-4">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.recorrente}
                  onChange={(e) => setFormData({ ...formData, recorrente: e.target.checked })}
                  className="w-4 h-4 rounded border-border"
                />
                <span className="text-sm">Recorrente</span>
              </label>
              
              {formData.recorrente && (
                <Select
                  value={formData.frequencia}
                  onValueChange={(v) => setFormData({ ...formData, frequencia: v as typeof formData.frequencia })}
                >
                  <SelectTrigger className="w-32 bg-secondary border-border">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    <SelectItem value="diaria">Diária</SelectItem>
                    <SelectItem value="semanal">Semanal</SelectItem>
                    <SelectItem value="mensal">Mensal</SelectItem>
                    <SelectItem value="anual">Anual</SelectItem>
                  </SelectContent>
                </Select>
              )}
            </div>
          </div>

          <DialogFooter className="mt-4">
            <Button
              variant="outline"
              onClick={() => {
                resetForm();
                setDialogOpen(false);
              }}
              className="border-border"
            >
              Cancelar
            </Button>
            <Button
              onClick={handleAddDespesa}
              disabled={!formData.descricao.trim() || !formData.valor}
              className="bg-primary text-primary-foreground hover:bg-primary/90"
            >
              Adicionar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog Editar Despesa */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="bg-card border-border max-w-md">
          <DialogHeader>
            <DialogTitle className="text-primary">Editar Despesa</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 pt-4">
            <Input
              placeholder="Descrição *"
              value={formData.descricao}
              onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
              className="border-border bg-secondary focus:border-primary"
            />
            
            <div className="grid grid-cols-2 gap-3">
              <Input
                placeholder="Valor *"
                value={formData.valor}
                onChange={(e) => setFormData({ ...formData, valor: e.target.value })}
                className="border-border bg-secondary focus:border-primary"
              />
              
              <Select
                value={formData.categoria}
                onValueChange={(v) => setFormData({ ...formData, categoria: v as CategoriaDespesa })}
              >
                <SelectTrigger className="bg-secondary border-border">
                  <SelectValue placeholder="Categoria" />
                </SelectTrigger>
                <SelectContent className="bg-card border-border">
                  {CATEGORIAS.map((cat) => (
                    <SelectItem key={cat.value} value={cat.value}>
                      {cat.icon} {cat.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <label className="text-sm text-muted-foreground">Data</label>
                <Input
                  type="date"
                  value={formData.data}
                  onChange={(e) => setFormData({ ...formData, data: e.target.value })}
                  className="border-border bg-secondary focus:border-primary"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm text-muted-foreground">Vencimento</label>
                <Input
                  type="date"
                  value={formData.dataVencimento}
                  onChange={(e) => setFormData({ ...formData, dataVencimento: e.target.value })}
                  className="border-border bg-secondary focus:border-primary"
                />
              </div>
            </div>

            <Input
              placeholder="Observação (opcional)"
              value={formData.observacao}
              onChange={(e) => setFormData({ ...formData, observacao: e.target.value })}
              className="border-border bg-secondary focus:border-primary"
            />

            <div className="flex items-center gap-4">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.recorrente}
                  onChange={(e) => setFormData({ ...formData, recorrente: e.target.checked })}
                  className="w-4 h-4 rounded border-border"
                />
                <span className="text-sm">Recorrente</span>
              </label>
              
              {formData.recorrente && (
                <Select
                  value={formData.frequencia}
                  onValueChange={(v) => setFormData({ ...formData, frequencia: v as typeof formData.frequencia })}
                >
                  <SelectTrigger className="w-32 bg-secondary border-border">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    <SelectItem value="diaria">Diária</SelectItem>
                    <SelectItem value="semanal">Semanal</SelectItem>
                    <SelectItem value="mensal">Mensal</SelectItem>
                    <SelectItem value="anual">Anual</SelectItem>
                  </SelectContent>
                </Select>
              )}
            </div>

            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.paga}
                onChange={(e) => setFormData({ ...formData, paga: e.target.checked })}
                className="w-4 h-4 rounded border-border"
              />
              <span className="text-sm">Já está paga</span>
            </label>
          </div>

          <DialogFooter className="mt-4">
            <Button
              variant="outline"
              onClick={() => {
                resetForm();
                setDespesaEditando(null);
                setEditDialogOpen(false);
              }}
              className="border-border"
            >
              Cancelar
            </Button>
            <Button
              onClick={handleEditDespesa}
              disabled={!formData.descricao.trim() || !formData.valor}
              className="bg-primary text-primary-foreground hover:bg-primary/90"
            >
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
