'use client';

import { useState } from 'react';
import { Download, X, TrendingUp, Users, DollarSign, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import type { Venda, Barbeiro, Servico, FormaPagamento } from '@/lib/types';

interface RelatorioModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  vendas: Venda[];
  barbeiros: Barbeiro[];
  servicos: Servico[];
}

// Cores para os gráficos
const COLORS = ['#ffb400', '#ffc940', '#d49b00', '#b8860b', '#ffd700'];

export default function RelatorioModal({
  open,
  onOpenChange,
  vendas,
  barbeiros,
  servicos,
}: RelatorioModalProps) {
  const [periodo, setPeriodo] = useState<'hoje' | 'semana' | 'mes'>('hoje');

  // Filtrar vendas por período
  const filtrarVendasPorPeriodo = () => {
    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);

    return vendas.filter((venda) => {
      const dataVenda = new Date(venda.data);
      dataVenda.setHours(0, 0, 0, 0);

      if (periodo === 'hoje') {
        return dataVenda.getTime() === hoje.getTime();
      } else if (periodo === 'semana') {
        const semanaAtras = new Date(hoje);
        semanaAtras.setDate(semanaAtras.getDate() - 7);
        return dataVenda >= semanaAtras;
      } else {
        const mesAtras = new Date(hoje);
        mesAtras.setMonth(mesAtras.getMonth() - 1);
        return dataVenda >= mesAtras;
      }
    });
  };

  const vendasFiltradas = filtrarVendasPorPeriodo();

  // Dados para gráfico de vendas por barbeiro
  const dadosPorBarbeiro = barbeiros.map((barbeiro) => {
    const vendasBarbeiro = vendasFiltradas.filter(
      (v) => v.barbeiroId === barbeiro.id
    );
    return {
      nome: barbeiro.nome,
      total: vendasBarbeiro.reduce((acc, v) => acc + v.preco, 0),
      quantidade: vendasBarbeiro.length,
    };
  });

  // Dados para gráfico de serviços mais vendidos
  const dadosPorServico = servicos.map((servico) => {
    const vendasServico = vendasFiltradas.filter((v) => v.servicoId === servico.id);
    return {
      nome: servico.nome,
      quantidade: vendasServico.length,
      total: vendasServico.reduce((acc, v) => acc + v.preco, 0),
    };
  }).sort((a, b) => b.quantidade - a.quantidade).slice(0, 5);

  // Dados para gráfico de formas de pagamento
  const dadosPorPagamento: { name: string; value: number; color: string }[] = [
    {
      name: 'Dinheiro',
      value: vendasFiltradas.filter((v) => v.formaPagamento === 'dinheiro').reduce((acc, v) => acc + v.preco, 0),
      color: '#22c55e',
    },
    {
      name: 'Cartão',
      value: vendasFiltradas.filter((v) => v.formaPagamento === 'cartao').reduce((acc, v) => acc + v.preco, 0),
      color: '#3b82f6',
    },
    {
      name: 'PIX',
      value: vendasFiltradas.filter((v) => v.formaPagamento === 'pix').reduce((acc, v) => acc + v.preco, 0),
      color: '#a855f7',
    },
  ].filter((item) => item.value > 0);

  // Calcular totais
  const totalGeral = vendasFiltradas.reduce((acc, v) => acc + v.preco, 0);
  const totalVendas = vendasFiltradas.length;

  // Formatar moeda
  const formatPreco = (preco: number) => {
    return preco.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    });
  };

  // Exportar relatório como texto
  const exportarRelatorio = () => {
    const dataAtual = new Date().toLocaleDateString('pt-BR');
    let texto = `═══════════════════════════════════════\n`;
    texto += `        RELATÓRIO - BARBEARIA PRO\n`;
    texto += `═══════════════════════════════════════\n\n`;
    texto += `📅 Data: ${dataAtual}\n`;
    texto += `📊 Período: ${periodo === 'hoje' ? 'Hoje' : periodo === 'semana' ? 'Última Semana' : 'Último Mês'}\n\n`;
    
    texto += `─────────────────────────────────────\n`;
    texto += `             RESUMO GERAL\n`;
    texto += `─────────────────────────────────────\n`;
    texto += `💰 Total: ${formatPreco(totalGeral)}\n`;
    texto += `📋 Vendas: ${totalVendas}\n\n`;

    texto += `─────────────────────────────────────\n`;
    texto += `         VENDAS POR BARBEIRO\n`;
    texto += `─────────────────────────────────────\n`;
    dadosPorBarbeiro.forEach((b) => {
      texto += `• ${b.nome}: ${formatPreco(b.total)} (${b.quantidade} vendas)\n`;
    });
    texto += `\n`;

    texto += `─────────────────────────────────────\n`;
    texto += `       SERVIÇOS MAIS VENDIDOS\n`;
    texto += `─────────────────────────────────────\n`;
    dadosPorServico.forEach((s, i) => {
      texto += `${i + 1}. ${s.nome}: ${s.quantidade}x - ${formatPreco(s.total)}\n`;
    });
    texto += `\n`;

    texto += `─────────────────────────────────────\n`;
    texto += `        FORMAS DE PAGAMENTO\n`;
    texto += `─────────────────────────────────────\n`;
    dadosPorPagamento.forEach((p) => {
      texto += `• ${p.name}: ${formatPreco(p.value)}\n`;
    });
    texto += `\n`;

    texto += `═══════════════════════════════════════\n`;
    texto += `      Sistema de Gestão Barbearia Pro\n`;
    texto += `═══════════════════════════════════════\n`;

    // Criar blob e download
    const blob = new Blob([texto], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `relatorio-barbearia-${dataAtual.replace(/\//g, '-')}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden bg-card border-border">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-primary flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Relatório de Vendas
            </DialogTitle>
            <Button
              variant="outline"
              size="sm"
              onClick={exportarRelatorio}
              className="border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground"
            >
              <Download className="mr-2 h-4 w-4" />
              Exportar
            </Button>
          </div>
        </DialogHeader>

        {/* Filtros de período */}
        <div className="flex gap-2 mt-2">
          {(['hoje', 'semana', 'mes'] as const).map((p) => (
            <Button
              key={p}
              size="sm"
              variant={periodo === p ? 'default' : 'outline'}
              className={
                periodo === p
                  ? 'bg-primary text-primary-foreground'
                  : 'border-border text-muted-foreground'
              }
              onClick={() => setPeriodo(p)}
            >
              {p === 'hoje' ? 'Hoje' : p === 'semana' ? 'Semana' : 'Mês'}
            </Button>
          ))}
        </div>

        {/* Resumo rápido */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">
          <Card className="bg-secondary/50 border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-xs text-muted-foreground">Total</p>
                  <p className="text-lg font-bold text-primary">
                    {formatPreco(totalGeral)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-secondary/50 border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-xs text-muted-foreground">Vendas</p>
                  <p className="text-lg font-bold text-foreground">{totalVendas}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-secondary/50 border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-xs text-muted-foreground">Barbeiros</p>
                  <p className="text-lg font-bold text-foreground">
                    {barbeiros.length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-secondary/50 border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-xs text-muted-foreground">Ticket Médio</p>
                  <p className="text-lg font-bold text-foreground">
                    {totalVendas > 0 ? formatPreco(totalGeral / totalVendas) : 'R$ 0'}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Gráficos */}
        <Tabs defaultValue="barbeiro" className="mt-4">
          <TabsList className="bg-secondary/50">
            <TabsTrigger value="barbeiro" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              Por Barbeiro
            </TabsTrigger>
            <TabsTrigger value="servico" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              Por Serviço
            </TabsTrigger>
            <TabsTrigger value="pagamento" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              Pagamento
            </TabsTrigger>
          </TabsList>

          <TabsContent value="barbeiro" className="mt-4">
            <Card className="bg-secondary/30 border-border">
              <CardHeader>
                <CardTitle className="text-sm text-muted-foreground">
                  Vendas por Barbeiro
                </CardTitle>
              </CardHeader>
              <CardContent>
                {dadosPorBarbeiro.length > 0 && dadosPorBarbeiro.some(d => d.total > 0) ? (
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={dadosPorBarbeiro}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                      <XAxis dataKey="nome" stroke="#a0a0a0" fontSize={12} />
                      <YAxis stroke="#a0a0a0" fontSize={12} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#1e1e1e',
                          border: '1px solid #333',
                          borderRadius: '8px',
                        }}
                        labelStyle={{ color: '#ffb400' }}
                        formatter={(value: number) => [formatPreco(value), 'Total']}
                      />
                      <Bar dataKey="total" fill="#ffb400" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-[250px] text-muted-foreground">
                    Sem dados para exibir
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="servico" className="mt-4">
            <Card className="bg-secondary/30 border-border">
              <CardHeader>
                <CardTitle className="text-sm text-muted-foreground">
                  Serviços Mais Vendidos
                </CardTitle>
              </CardHeader>
              <CardContent>
                {dadosPorServico.length > 0 ? (
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={dadosPorServico} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                      <XAxis type="number" stroke="#a0a0a0" fontSize={12} />
                      <YAxis dataKey="nome" type="category" stroke="#a0a0a0" fontSize={12} width={80} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#1e1e1e',
                          border: '1px solid #333',
                          borderRadius: '8px',
                        }}
                        labelStyle={{ color: '#ffb400' }}
                        formatter={(value: number) => [value, 'Quantidade']}
                      />
                      <Bar dataKey="quantidade" fill="#ffc940" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-[250px] text-muted-foreground">
                    Sem dados para exibir
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="pagamento" className="mt-4">
            <Card className="bg-secondary/30 border-border">
              <CardHeader>
                <CardTitle className="text-sm text-muted-foreground">
                  Formas de Pagamento
                </CardTitle>
              </CardHeader>
              <CardContent>
                {dadosPorPagamento.length > 0 ? (
                  <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                      <Pie
                        data={dadosPorPagamento}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={5}
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        labelLine={false}
                      >
                        {dadosPorPagamento.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#1e1e1e',
                          border: '1px solid #333',
                          borderRadius: '8px',
                        }}
                        formatter={(value: number) => [formatPreco(value), 'Total']}
                      />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-[250px] text-muted-foreground">
                    Sem dados para exibir
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
