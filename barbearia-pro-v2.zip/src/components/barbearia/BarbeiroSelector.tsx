'use client';

import { User, Trash2, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { Barbeiro } from '@/lib/types';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

interface BarbeiroSelectorProps {
  barbeiros: Barbeiro[];
  barbeiroAtivoId: string | null;
  onSelectBarbeiro: (id: string) => void;
  onRemoveBarbeiro: (id: string) => void;
}

export default function BarbeiroSelector({
  barbeiros,
  barbeiroAtivoId,
  onSelectBarbeiro,
  onRemoveBarbeiro,
}: BarbeiroSelectorProps) {
  if (barbeiros.length === 0) {
    return (
      <Card className="border-dashed border-border bg-card/50">
        <CardContent className="flex flex-col items-center justify-center py-8">
          <User className="mb-2 h-10 w-10 text-muted-foreground" />
          <p className="text-center text-muted-foreground">
            Nenhum barbeiro cadastrado
          </p>
          <p className="text-sm text-muted-foreground/70">
            Clique em "Novo Barbeiro" para adicionar
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <User className="h-4 w-4 text-primary" />
        <h2 className="text-sm font-medium text-muted-foreground">
          Selecione o Barbeiro
        </h2>
      </div>
      
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
        {barbeiros.map((barbeiro) => {
          const isActive = barbeiroAtivoId === barbeiro.id;
          
          return (
            <Card
              key={barbeiro.id}
              className={`relative cursor-pointer transition-all duration-200 hover:scale-[1.02] ${
                isActive
                  ? 'border-primary bg-primary/10 shadow-lg shadow-primary/20'
                  : 'border-border bg-card hover:border-primary/50'
              }`}
              onClick={() => onSelectBarbeiro(barbeiro.id)}
            >
              <CardContent className="flex items-center gap-3 p-3">
                {/* Avatar */}
                <div
                  className={`flex h-10 w-10 items-center justify-center rounded-full ${
                    isActive ? 'bg-primary' : 'bg-secondary'
                  }`}
                >
                  {isActive ? (
                    <Check className="h-5 w-5 text-primary-foreground" />
                  ) : (
                    <User className="h-5 w-5 text-muted-foreground" />
                  )}
                </div>

                {/* Nome */}
                <div className="flex-1 min-w-0">
                  <p className={`font-medium truncate ${isActive ? 'text-primary' : 'text-foreground'}`}>
                    {barbeiro.nome}
                  </p>
                  {isActive && (
                    <Badge variant="outline" className="text-xs border-primary text-primary">
                      Ativo
                    </Badge>
                  )}
                </div>

                {/* Botão de remover */}
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent className="bg-card border-border">
                    <AlertDialogHeader>
                      <AlertDialogTitle className="text-foreground">
                        Remover Barbeiro
                      </AlertDialogTitle>
                      <AlertDialogDescription className="text-muted-foreground">
                        Tem certeza que deseja remover <strong>{barbeiro.nome}</strong>? 
                        Todas as vendas deste barbeiro serão perdidas.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel className="border-border">
                        Cancelar
                      </AlertDialogCancel>
                      <AlertDialogAction
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        onClick={() => onRemoveBarbeiro(barbeiro.id)}
                      >
                        Remover
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
