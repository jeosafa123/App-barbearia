'use client';

import { DollarSign, TrendingUp, Users, Scissors } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

interface ResumoCardProps {
  title: string;
  value: string | number;
  icon: 'money' | 'sales' | 'barbers' | 'services';
  highlight?: boolean;
}

const iconMap = {
  money: DollarSign,
  sales: TrendingUp,
  barbers: Users,
  services: Scissors,
};

const iconColorMap = {
  money: 'text-primary',
  sales: 'text-green-400',
  barbers: 'text-blue-400',
  services: 'text-purple-400',
};

export default function ResumoCard({
  title,
  value,
  icon,
  highlight = false,
}: ResumoCardProps) {
  const Icon = iconMap[icon];
  const iconColor = iconColorMap[icon];

  return (
    <Card
      className={`transition-all duration-200 hover:scale-[1.02] ${
        highlight
          ? 'bg-primary/10 border-primary/30 shadow-lg shadow-primary/10'
          : 'bg-card border-border'
      }`}
    >
      <CardContent className="flex items-center gap-4 p-4">
        <div
          className={`flex h-12 w-12 items-center justify-center rounded-lg ${
            highlight ? 'bg-primary/20' : 'bg-secondary'
          }`}
        >
          <Icon className={`h-6 w-6 ${iconColor}`} />
        </div>
        <div>
          <p className="text-sm text-muted-foreground">{title}</p>
          <p
            className={`text-xl font-bold ${
              highlight ? 'text-primary' : 'text-foreground'
            }`}
          >
            {value}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
