'use client';

import { useState, useEffect, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  LayoutDashboard, ShoppingBag, Users, Calendar, 
  Receipt, BarChart3, Settings, Scissors, Sparkles
} from 'lucide-react';

// Componentes da barbearia
import SplashScreen from '@/components/barbearia/SplashScreen';
import DashboardSection from '@/components/barbearia/DashboardSection';
import ServicosGrid from '@/components/barbearia/ServicosGrid';
import VendasTable from '@/components/barbearia/VendasTable';
import ClientesSection from '@/components/barbearia/ClientesSection';
import AgendamentosSection from '@/components/barbearia/AgendamentosSection';
import DespesasSection from '@/components/barbearia/DespesasSection';
import RelatorioModal from '@/components/barbearia/RelatorioModal';
import ConfiguracoesSection from '@/components/barbearia/ConfiguracoesSection';
import BarbeiroSelector from '@/components/barbearia/BarbeiroSelector';
import ResumoCard from '@/components/barbearia/ResumoCard';

// Tipos
import type { 
  Barbeiro, Servico, Venda, FormaPagamento, 
  Cliente, Agendamento, StatusAgendamento, 
  Despesa, CategoriaDespesa, BackupData, TabId 
} from '@/lib/types';

// Constantes para localStorage
const STORAGE_KEYS = {
  barbeiros: 'barbearia_barbeiros_v2',
  servicos: 'barbearia_servicos_v2',
  vendas: 'barbearia_vendas_v2',
  clientes: 'barbearia_clientes_v2',
  agendamentos: 'barbearia_agendamentos_v2',
  despesas: 'barbearia_despesas_v2',
  barbeiroAtivo: 'barbearia_barbeiro_ativo_v2',
  activeTab: 'barbearia_active_tab',
};

// Dados iniciais padrão
const DEFAULT_SERVICOS: Servico[] = [
  { id: '1', nome: 'Corte', preco: 35.0, duracao: 30, ativo: true },
  { id: '2', nome: 'Barba', preco: 25.0, duracao: 20, ativo: true },
  { id: '3', nome: 'Corte + Barba', preco: 50.0, duracao: 45, ativo: true },
  { id: '4', nome: 'Sobrancelha', preco: 10.0, duracao: 10, ativo: true },
  { id: '5', nome: 'Pigmentação', preco: 45.0, duracao: 40, ativo: true },
  { id: '6', nome: 'Hidratação', preco: 30.0, duracao: 30, ativo: true },
  { id: '7', nome: 'Corte Degradê', preco: 45.0, duracao: 40, ativo: true },
  { id: '8', nome: 'Combo Premium', preco: 80.0, duracao: 60, ativo: true },
];

const DEFAULT_BARBEIROS: Barbeiro[] = [
  { id: '1', nome: 'João', ativo: false, comissao: 40, dataCadastro: new Date().toISOString() },
  { id: '2', nome: 'Pedro', ativo: false, comissao: 40, dataCadastro: new Date().toISOString() },
  { id: '3', nome: 'Carlos', ativo: false, comissao: 35, dataCadastro: new Date().toISOString() },
];

export default function BarbeariaApp() {
  const { toast } = useToast();
  
  // Estado da aplicação
  const [isLoading, setIsLoading] = useState(true);
  const [barbeiros, setBarbeiros] = useState<Barbeiro[]>([]);
  const [servicos, setServicos] = useState<Servico[]>([]);
  const [vendas, setVendas] = useState<Venda[]>([]);
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [agendamentos, setAgendamentos] = useState<Agendamento[]>([]);
  const [despesas, setDespesas] = useState<Despesa[]>([]);
  const [barbeiroAtivoId, setBarbeiroAtivoId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<TabId>('dashboard');
  const [relatorioOpen, setRelatorioOpen] = useState(false);

  // Carregar dados do localStorage
  useEffect(() => {
    const loadData = () => {
      try {
        // Carregar barbeiros
        const storedBarbeiros = localStorage.getItem(STORAGE_KEYS.barbeiros);
        if (storedBarbeiros) {
          setBarbeiros(JSON.parse(storedBarbeiros));
        } else {
          setBarbeiros(DEFAULT_BARBEIROS);
          localStorage.setItem(STORAGE_KEYS.barbeiros, JSON.stringify(DEFAULT_BARBEIROS));
        }

        // Carregar serviços
        const storedServicos = localStorage.getItem(STORAGE_KEYS.servicos);
        if (storedServicos) {
          setServicos(JSON.parse(storedServicos));
        } else {
          setServicos(DEFAULT_SERVICOS);
          localStorage.setItem(STORAGE_KEYS.servicos, JSON.stringify(DEFAULT_SERVICOS));
        }

        // Carregar vendas
        const storedVendas = localStorage.getItem(STORAGE_KEYS.vendas);
        if (storedVendas) {
          setVendas(JSON.parse(storedVendas));
        }

        // Carregar clientes
        const storedClientes = localStorage.getItem(STORAGE_KEYS.clientes);
        if (storedClientes) {
          setClientes(JSON.parse(storedClientes));
        }

        // Carregar agendamentos
        const storedAgendamentos = localStorage.getItem(STORAGE_KEYS.agendamentos);
        if (storedAgendamentos) {
          setAgendamentos(JSON.parse(storedAgendamentos));
        }

        // Carregar despesas
        const storedDespesas = localStorage.getItem(STORAGE_KEYS.despesas);
        if (storedDespesas) {
          setDespesas(JSON.parse(storedDespesas));
        }

        // Carregar barbeiro ativo
        const storedBarbeiroAtivo = localStorage.getItem(STORAGE_KEYS.barbeiroAtivo);
        if (storedBarbeiroAtivo) {
          setBarbeiroAtivoId(storedBarbeiroAtivo);
        }

        // Carregar tab ativa
        const storedActiveTab = localStorage.getItem(STORAGE_KEYS.activeTab) as TabId;
        if (storedActiveTab) {
          setActiveTab(storedActiveTab);
        }
      } catch (error) {
        console.error('Erro ao carregar dados:', error);
        setBarbeiros(DEFAULT_BARBEIROS);
        setServicos(DEFAULT_SERVICOS);
      }
    };

    loadData();
  }, []);

  // Salvar dados no localStorage quando mudam
  useEffect(() => {
    if (barbeiros.length > 0) {
      localStorage.setItem(STORAGE_KEYS.barbeiros, JSON.stringify(barbeiros));
    }
  }, [barbeiros]);

  useEffect(() => {
    if (servicos.length > 0) {
      localStorage.setItem(STORAGE_KEYS.servicos, JSON.stringify(servicos));
    }
  }, [servicos]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.vendas, JSON.stringify(vendas));
  }, [vendas]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.clientes, JSON.stringify(clientes));
  }, [clientes]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.agendamentos, JSON.stringify(agendamentos));
  }, [agendamentos]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.despesas, JSON.stringify(despesas));
  }, [despesas]);

  useEffect(() => {
    if (barbeiroAtivoId) {
      localStorage.setItem(STORAGE_KEYS.barbeiroAtivo, barbeiroAtivoId);
    }
  }, [barbeiroAtivoId]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.activeTab, activeTab);
  }, [activeTab]);

  // Handlers
  const handleSplashComplete = useCallback(() => {
    setIsLoading(false);
  }, []);

  // ==================== BARBEIROS ====================
  const handleAddBarbeiro = useCallback((nome: string) => {
    const novoBarbeiro: Barbeiro = {
      id: uuidv4(),
      nome,
      ativo: false,
      comissao: 40,
      dataCadastro: new Date().toISOString(),
    };
    setBarbeiros((prev) => [...prev, novoBarbeiro]);
    toast({
      title: 'Barbeiro adicionado',
      description: `${nome} foi adicionado com sucesso!`,
    });
  }, [toast]);

  const handleSelectBarbeiro = useCallback((id: string) => {
    setBarbeiroAtivoId(id);
    const barbeiro = barbeiros.find((b) => b.id === id);
    if (barbeiro) {
      toast({
        title: 'Barbeiro selecionado',
        description: `${barbeiro.nome} está ativo agora.`,
      });
    }
  }, [barbeiros, toast]);

  const handleRemoveBarbeiro = useCallback((id: string) => {
    const barbeiro = barbeiros.find((b) => b.id === id);
    setBarbeiros((prev) => prev.filter((b) => b.id !== id));
    setVendas((prev) => prev.filter((v) => v.barbeiroId !== id));
    if (barbeiroAtivoId === id) {
      setBarbeiroAtivoId(null);
    }
    toast({
      title: 'Barbeiro removido',
      description: `${barbeiro?.nome} foi removido com sucesso.`,
    });
  }, [barbeiros, barbeiroAtivoId, toast]);

  // ==================== SERVIÇOS ====================
  const handleAddServico = useCallback((nome: string, preco: number) => {
    const novoServico: Servico = {
      id: uuidv4(),
      nome,
      preco,
      duracao: 30,
      ativo: true,
    };
    setServicos((prev) => [...prev, novoServico]);
    toast({
      title: 'Serviço adicionado',
      description: `${nome} - R$ ${preco.toFixed(2)} foi adicionado!`,
    });
  }, [toast]);

  const handleEditServico = useCallback((id: string, nome: string, preco: number) => {
    setServicos((prev) =>
      prev.map((s) => (s.id === id ? { ...s, nome, preco } : s))
    );
    toast({
      title: 'Serviço atualizado',
      description: `${nome} foi atualizado com sucesso!`,
    });
  }, [toast]);

  const handleDeleteServico = useCallback((id: string) => {
    const servico = servicos.find((s) => s.id === id);
    setServicos((prev) => prev.filter((s) => s.id !== id));
    toast({
      title: 'Serviço removido',
      description: `${servico?.nome} foi removido.`,
    });
  }, [servicos, toast]);

  // ==================== VENDAS ====================
  const handleRegistrarVenda = useCallback((servicoId: string, formaPagamento: FormaPagamento) => {
    const servico = servicos.find((s) => s.id === servicoId);
    const barbeiro = barbeiros.find((b) => b.id === barbeiroAtivoId);

    if (!servico || !barbeiro) return;

    const agora = new Date();
    const comissao = (servico.preco * barbeiro.comissao) / 100;
    
    const novaVenda: Venda = {
      id: uuidv4(),
      barbeiroId: barbeiro.id,
      barbeiroNome: barbeiro.nome,
      servicoId: servico.id,
      servicoNome: servico.nome,
      preco: servico.preco,
      formaPagamento,
      data: agora.toISOString().split('T')[0],
      hora: agora.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
      comissao,
    };

    setVendas((prev) => [novaVenda, ...prev]);
    toast({
      title: 'Venda registrada!',
      description: `${servico.nome} - R$ ${servico.preco.toFixed(2)} (${formaPagamento})`,
    });
  }, [servicos, barbeiros, barbeiroAtivoId, toast]);

  const handleDeleteVenda = useCallback((id: string) => {
    setVendas((prev) => prev.filter((v) => v.id !== id));
    toast({
      title: 'Venda removida',
      description: 'A venda foi removida do histórico.',
    });
  }, [toast]);

  // ==================== CLIENTES ====================
  const handleAddCliente = useCallback((clienteData: Omit<Cliente, 'id' | 'dataCadastro' | 'totalVisitas' | 'totalGasto'>) => {
    const novoCliente: Cliente = {
      id: uuidv4(),
      ...clienteData,
      dataCadastro: new Date().toISOString(),
      totalVisitas: 0,
      totalGasto: 0,
    };
    setClientes((prev) => [...prev, novoCliente]);
    toast({
      title: 'Cliente cadastrado',
      description: `${clienteData.nome} foi adicionado!`,
    });
  }, [toast]);

  const handleEditCliente = useCallback((id: string, clienteData: Partial<Cliente>) => {
    setClientes((prev) =>
      prev.map((c) => (c.id === id ? { ...c, ...clienteData } : c))
    );
    toast({
      title: 'Cliente atualizado',
      description: 'Os dados foram salvos.',
    });
  }, [toast]);

  const handleDeleteCliente = useCallback((id: string) => {
    setClientes((prev) => prev.filter((c) => c.id !== id));
    toast({
      title: 'Cliente removido',
      description: 'O cliente foi removido.',
    });
  }, [toast]);

  // ==================== AGENDAMENTOS ====================
  const handleAddAgendamento = useCallback((agendamentoData: Omit<Agendamento, 'id' | 'dataCriacao'>) => {
    const novoAgendamento: Agendamento = {
      id: uuidv4(),
      ...agendamentoData,
      dataCriacao: new Date().toISOString(),
    };
    setAgendamentos((prev) => [...prev, novoAgendamento]);
    toast({
      title: 'Agendamento criado!',
      description: `${agendamentoData.clienteNome} - ${agendamentoData.data} às ${agendamentoData.hora}`,
    });
  }, [toast]);

  const handleUpdateStatusAgendamento = useCallback((id: string, status: StatusAgendamento) => {
    setAgendamentos((prev) =>
      prev.map((a) => (a.id === id ? { ...a, status } : a))
    );
    
    // Se concluído, registrar venda automaticamente
    if (status === 'concluido') {
      const agendamento = agendamentos.find((a) => a.id === id);
      if (agendamento && barbeiroAtivoId) {
        const barbeiro = barbeiros.find((b) => b.id === agendamento.barbeiroId);
        if (barbeiro) {
          const comissao = (agendamento.preco * barbeiro.comissao) / 100;
          const novaVenda: Venda = {
            id: uuidv4(),
            barbeiroId: barbeiro.id,
            barbeiroNome: barbeiro.nome,
            clienteId: agendamento.clienteId,
            clienteNome: agendamento.clienteNome,
            servicoId: agendamento.servicoId,
            servicoNome: agendamento.servicoNome,
            preco: agendamento.preco,
            formaPagamento: 'dinheiro',
            data: agendamento.data,
            hora: agendamento.hora,
            comissao,
          };
          setVendas((prev) => [novaVenda, ...prev]);
        }
      }
    }
    
    toast({
      title: 'Status atualizado',
      description: `Agendamento marcado como ${status}.`,
    });
  }, [agendamentos, barbeiroAtivoId, barbeiros, toast]);

  const handleDeleteAgendamento = useCallback((id: string) => {
    setAgendamentos((prev) => prev.filter((a) => a.id !== id));
    toast({
      title: 'Agendamento removido',
      description: 'O agendamento foi cancelado.',
    });
  }, [toast]);

  // ==================== DESPESAS ====================
  const handleAddDespesa = useCallback((despesaData: Omit<Despesa, 'id'>) => {
    const novaDespesa: Despesa = {
      id: uuidv4(),
      ...despesaData,
    };
    setDespesas((prev) => [...prev, novaDespesa]);
    toast({
      title: 'Despesa registrada',
      description: `${despesaData.descricao} - R$ ${despesaData.valor.toFixed(2)}`,
    });
  }, [toast]);

  const handleEditDespesa = useCallback((id: string, despesaData: Partial<Despesa>) => {
    setDespesas((prev) =>
      prev.map((d) => (d.id === id ? { ...d, ...despesaData } : d))
    );
    toast({
      title: 'Despesa atualizada',
      description: 'Os dados foram salvos.',
    });
  }, [toast]);

  const handleDeleteDespesa = useCallback((id: string) => {
    setDespesas((prev) => prev.filter((d) => d.id !== id));
    toast({
      title: 'Despesa removida',
      description: 'A despesa foi excluída.',
    });
  }, [toast]);

  const handleMarcarDespesaPaga = useCallback((id: string) => {
    setDespesas((prev) =>
      prev.map((d) => (d.id === id ? { ...d, paga: true, dataPagamento: new Date().toISOString().split('T')[0] } : d))
    );
    toast({
      title: 'Despesa paga',
      description: 'A despesa foi marcada como paga.',
    });
  }, [toast]);

  // ==================== BACKUP/RESTORE ====================
  const handleExportData = useCallback((): BackupData => {
    return {
      versao: '2.0.0',
      dataExportacao: new Date().toISOString(),
      barbeiros,
      servicos,
      vendas,
      clientes,
      agendamentos,
      despesas,
      produtos: [],
      vendasProdutos: [],
    };
  }, [barbeiros, servicos, vendas, clientes, agendamentos, despesas]);

  const handleImportData = useCallback((data: BackupData) => {
    if (data.barbeiros) setBarbeiros(data.barbeiros);
    if (data.servicos) setServicos(data.servicos);
    if (data.vendas) setVendas(data.vendas);
    if (data.clientes) setClientes(data.clientes);
    if (data.agendamentos) setAgendamentos(data.agendamentos);
    if (data.despesas) setDespesas(data.despesas);
  }, []);

  const handleClearData = useCallback(() => {
    localStorage.clear();
    setBarbeiros(DEFAULT_BARBEIROS);
    setServicos(DEFAULT_SERVICOS);
    setVendas([]);
    setClientes([]);
    setAgendamentos([]);
    setDespesas([]);
    setBarbeiroAtivoId(null);
    toast({
      title: 'Dados limpos',
      description: 'Todos os dados foram removidos.',
    });
  }, [toast]);

  // Vendas do dia
  const vendasDoDia = vendas.filter((v) => {
    const hoje = new Date().toISOString().split('T')[0];
    return v.data === hoje;
  });

  // Barbeiro ativo
  const barbeiroAtivo = barbeiros.find((b) => b.id === barbeiroAtivoId);

  // Formatar preço
  const formatPreco = (preco: number) => {
    return preco.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    });
  };

  // Se está carregando, mostrar splash screen
  if (isLoading) {
    return <SplashScreen onComplete={handleSplashComplete} />;
  }

  return (
    <div className="min-h-screen bg-background force-dark">
      {/* Header com logo e barbeiro ativo */}
      <header className="sticky top-0 z-40 border-b border-border bg-card/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-primary/70 shadow-lg shadow-primary/20">
              <Scissors className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-primary">Barbearia Pro</h1>
              <p className="text-xs text-muted-foreground">Sistema de Gestão</p>
            </div>
          </div>

          {/* Barbeiro ativo + Relatório */}
          <div className="flex items-center gap-3">
            {barbeiroAtivo && (
              <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/30">
                <div className="h-6 w-6 rounded-full bg-primary flex items-center justify-center">
                  <span className="text-xs font-bold text-primary-foreground">
                    {barbeiroAtivo.nome.charAt(0)}
                  </span>
                </div>
                <span className="text-sm font-medium text-primary">{barbeiroAtivo.nome}</span>
              </div>
            )}
            
            <button
              onClick={() => setRelatorioOpen(true)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors"
            >
              <BarChart3 className="h-4 w-4 text-primary" />
              <span className="text-sm hidden sm:inline">Relatórios</span>
            </button>
          </div>
        </div>
      </header>

      {/* Navegação por abas */}
      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as TabId)} className="w-full">
        <div className="sticky top-[65px] z-30 bg-background/95 backdrop-blur-sm border-b border-border">
          <TabsList className="w-full justify-start h-auto p-2 bg-transparent gap-1 overflow-x-auto">
            <TabsTrigger 
              value="dashboard" 
              className="flex items-center gap-2 px-4 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              <LayoutDashboard className="h-4 w-4" />
              <span className="hidden sm:inline">Dashboard</span>
            </TabsTrigger>
            <TabsTrigger 
              value="vendas" 
              className="flex items-center gap-2 px-4 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              <ShoppingBag className="h-4 w-4" />
              <span className="hidden sm:inline">Vendas</span>
            </TabsTrigger>
            <TabsTrigger 
              value="clientes" 
              className="flex items-center gap-2 px-4 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              <Users className="h-4 w-4" />
              <span className="hidden sm:inline">Clientes</span>
            </TabsTrigger>
            <TabsTrigger 
              value="agendamentos" 
              className="flex items-center gap-2 px-4 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              <Calendar className="h-4 w-4" />
              <span className="hidden sm:inline">Agendamentos</span>
            </TabsTrigger>
            <TabsTrigger 
              value="despesas" 
              className="flex items-center gap-2 px-4 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              <Receipt className="h-4 w-4" />
              <span className="hidden sm:inline">Despesas</span>
            </TabsTrigger>
            <TabsTrigger 
              value="configuracoes" 
              className="flex items-center gap-2 px-4 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              <Settings className="h-4 w-4" />
              <span className="hidden sm:inline">Config</span>
            </TabsTrigger>
          </TabsList>
        </div>

        {/* Conteúdo das abas */}
        <main className="mx-auto max-w-7xl px-4 py-6">
          {/* DASHBOARD */}
          <TabsContent value="dashboard" className="mt-0 space-y-6">
            <DashboardSection
              vendas={vendas}
              barbeiros={barbeiros}
              servicos={servicos}
              agendamentos={agendamentos}
              despesas={despesas}
              clientes={clientes}
            />
          </TabsContent>

          {/* VENDAS */}
          <TabsContent value="vendas" className="mt-0 space-y-6">
            {/* Cards de resumo rápido */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <ResumoCard
                title="Total do Dia"
                value={formatPreco(vendasDoDia.reduce((acc, v) => acc + v.preco, 0))}
                icon="money"
                highlight
              />
              <ResumoCard
                title="Vendas Hoje"
                value={vendasDoDia.length}
                icon="sales"
              />
              <ResumoCard
                title="Barbeiros"
                value={barbeiros.length}
                icon="barbers"
              />
              <ResumoCard
                title="Serviços"
                value={servicos.length}
                icon="services"
              />
            </div>

            {/* Seletor de barbeiro */}
            <BarbeiroSelector
              barbeiros={barbeiros}
              barbeiroAtivoId={barbeiroAtivoId}
              onSelectBarbeiro={handleSelectBarbeiro}
              onRemoveBarbeiro={handleRemoveBarbeiro}
            />

            {/* Grid de serviços */}
            <ServicosGrid
              servicos={servicos}
              onAddServico={handleAddServico}
              onEditServico={handleEditServico}
              onDeleteServico={handleDeleteServico}
              onSelectServico={(servico) => {
                if (barbeiroAtivoId) {
                  handleRegistrarVenda(servico.id, 'dinheiro');
                }
              }}
              barbeiroAtivo={!!barbeiroAtivoId}
            />

            {/* Tabela de vendas */}
            <VendasTable
              vendas={vendasDoDia}
              servicos={servicos}
              onRegistrarVenda={handleRegistrarVenda}
              onDeleteVenda={handleDeleteVenda}
              barbeiroAtivo={!!barbeiroAtivoId}
              barbeiroAtivoNome={barbeiroAtivo?.nome || ''}
            />
          </TabsContent>

          {/* CLIENTES */}
          <TabsContent value="clientes" className="mt-0">
            <ClientesSection
              clientes={clientes}
              vendas={vendas}
              onAddCliente={handleAddCliente}
              onEditCliente={handleEditCliente}
              onDeleteCliente={handleDeleteCliente}
              onSelectCliente={() => {}}
            />
          </TabsContent>

          {/* AGENDAMENTOS */}
          <TabsContent value="agendamentos" className="mt-0">
            <AgendamentosSection
              agendamentos={agendamentos}
              barbeiros={barbeiros}
              servicos={servicos}
              clientes={clientes}
              onAddAgendamento={handleAddAgendamento}
              onUpdateStatus={handleUpdateStatusAgendamento}
              onDeleteAgendamento={handleDeleteAgendamento}
            />
          </TabsContent>

          {/* DESPESAS */}
          <TabsContent value="despesas" className="mt-0">
            <DespesasSection
              despesas={despesas}
              onAddDespesa={handleAddDespesa}
              onEditDespesa={handleEditDespesa}
              onDeleteDespesa={handleDeleteDespesa}
              onMarcarPaga={handleMarcarDespesaPaga}
            />
          </TabsContent>

          {/* CONFIGURAÇÕES */}
          <TabsContent value="configuracoes" className="mt-0">
            <ConfiguracoesSection
              onExportData={handleExportData}
              onImportData={handleImportData}
              onClearData={handleClearData}
            />
          </TabsContent>
        </main>
      </Tabs>

      {/* Modal de relatório */}
      <RelatorioModal
        open={relatorioOpen}
        onOpenChange={setRelatorioOpen}
        vendas={vendas}
        barbeiros={barbeiros}
        servicos={servicos}
      />

      {/* Toaster para notificações */}
      <Toaster />
    </div>
  );
}
